package com.tp.brwnee;

public class ItemWish {
    private String reason;
    private String points;
    private String rowId;
    private String wBrand;
    private String wPrice;
    private String wUrl;

    public ItemWish(String reason, String points, String rowId, String wBrand, String wPrice, String wUrl) {
        super();
        this.reason = reason;
        this.points = points;
        this.rowId = rowId;
        this.wBrand = wBrand;
        this.wPrice = wPrice;
        this.wUrl = wUrl;
    }



    public CharSequence getReason() {
        // TODO Auto-generated method stub
        return reason;
    }

    public CharSequence getPoints() {
        // TODO Auto-generated method stub
        return points;
    }

    public CharSequence getRowId() {
        // TODO Auto-generated method stub
        return rowId;
    }

    public CharSequence getWBrand() {
        // TODO Auto-generated method stub
        return wBrand;
    }

    public CharSequence getWPrice() {
        // TODO Auto-generated method stub
        return wPrice;
    }

    public CharSequence getWUrl() {
        // TODO Auto-generated method stub
        return wUrl;
    }
}
