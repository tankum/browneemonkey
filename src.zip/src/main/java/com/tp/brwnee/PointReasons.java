package com.tp.brwnee;

import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class PointReasons {
	
	public static final String KEY_ROWID = "_id";
	public static final String KEY_RELREASON = "_reason";
	public static final String KEY_RELPOINTS = "_points";
	public static final String KEY_TYPE = "_type";
	public static final String KEY_CHILD = "_name";

	private static final String DATABASE_NAME = "reasonDb";
	private static final String DATABASE_TABLE = "reasonTable";
	private static final int DATABASE_VERSION = 1;
	
	private DbHelper myHelper;
	private Context myContext;
	private SQLiteDatabase myDatabase;
	
	private class DbHelper extends SQLiteOpenHelper{

		public DbHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL("CREATE TABLE " + DATABASE_TABLE + " ("+
					KEY_ROWID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
					KEY_RELREASON + " TEXT NOT NULL, " +
					KEY_RELPOINTS + " TEXT NOT NULL, " +
					KEY_TYPE + " TEXT NOT NULL, " +
					KEY_CHILD + " TEXT NOT NULL);"
					);
			}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);			
		}		
	}
	
	public PointReasons(Context cR){
		myContext = cR;
	}
	
	public PointReasons open() throws SQLException{
		myHelper = new DbHelper(myContext);
		myDatabase = myHelper.getWritableDatabase();	
		return this;
	}
	
	public void close(){
		myHelper.close();
	}

	public long createReasonEntry(String pReason, String toAdd, String rType, String childUnId) {
		
		// TODO Auto-generated method stub
		ContentValues cv = new ContentValues();
		cv.put(KEY_RELREASON, pReason);
		cv.put(KEY_RELPOINTS, toAdd);
		cv.put(KEY_TYPE, rType);
		cv.put(KEY_CHILD, childUnId);
		
		return myDatabase.insert(DATABASE_TABLE, null, cv);
		
	}

	public Cursor readReasonEntry() {
		// TODO Auto-generated method stub
		
		String[] columns = new String[]{KEY_ROWID, KEY_RELREASON, KEY_RELPOINTS, KEY_TYPE, KEY_CHILD};
		Cursor k = myDatabase.query(DATABASE_TABLE, columns, null, null, null, null, null);
		if(k!=null){
			k.moveToFirst();
		}
		return k;
	}

	public void modifyEntry(long rUD, String pReason, String toAdd, String rType, String childUnId) {
		// TODO Auto-generated method stub

		ContentValues cvUpdate = new ContentValues();
		cvUpdate.put(KEY_RELREASON, pReason);
		cvUpdate.put(KEY_RELPOINTS, toAdd);
		cvUpdate.put(KEY_TYPE, rType);
		cvUpdate.put(KEY_CHILD, childUnId);

		myDatabase.update(DATABASE_TABLE, cvUpdate, KEY_ROWID + "=" + rUD, null);

	}

	public void deleteEntry(long lR) {
		// TODO Auto-generated method stub
		myDatabase.delete(DATABASE_TABLE, KEY_ROWID + "=" + lR, null);
	}
	

	public void deleteReason(String reasonType, String childUnId) {
		// TODO Auto-generated method stub
		try
	    {
			myDatabase.delete(DATABASE_TABLE,
					KEY_TYPE + " = ? AND " + KEY_CHILD + " = ?",
					new String[] {reasonType, childUnId});

		}
	    catch(Exception e)
	    {
	        e.printStackTrace();
	    }
	    finally
	    {
	        myDatabase.close();
	    }
		
	}
}
