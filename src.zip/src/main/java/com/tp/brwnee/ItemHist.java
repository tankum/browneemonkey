package com.tp.brwnee;

public class ItemHist {

    private String histDate;
    private String histActivity;
    private String histType;
    private String histPoints;

    public ItemHist(String histDate, String histActivity, String histType, String histPoints) {
        super();

        this.histDate = histDate;
        this.histActivity = histActivity;
        this.histType = histType;
        this.histPoints = histPoints;
    }


    public CharSequence gethistDate() {
        // TODO Auto-generated method stub
        return histDate;
    }

    public CharSequence gethistActivity() {
        // TODO Auto-generated method stub
        return histActivity;
    }

    public CharSequence gethistType() {
        // TODO Auto-generated method stub
        return histType;
    }

    public CharSequence gethistPoints() {
        // TODO Auto-generated method stub
        return histPoints;
    }
}
