package com.tp.brwnee;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
 
public class MyAdapterReason extends ArrayAdapter<ItemReason>{
 
        private final Context context;
        private final ArrayList<ItemReason> itemsArrayList;
 
        public MyAdapterReason(Context context, ArrayList<ItemReason> itemsArrayList) {

            super(context, R.layout.reason_row, itemsArrayList);
 
            this.context = context;
            this.itemsArrayList = itemsArrayList;
        }
 
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
 
            // 1. Create inflater
            LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
 
            // 2. Get rowView from inflater
            final View rowView = inflater.inflate(R.layout.reason_row, parent, false);
 
            // 3. Get the two text view from the rowView
            TextView reason = (TextView) rowView.findViewById(R.id.tvdbReason);
            TextView points = (TextView) rowView.findViewById(R.id.tvdbPoints);
            TextView reasonId = (TextView) rowView.findViewById(R.id.tvdbReasonRow);

 
            // 4. Set the text for textView
            reason.setText(itemsArrayList.get(position).getReason());
            points.setText(itemsArrayList.get(position).getPoints());
            reasonId.setText(itemsArrayList.get(position).getRowId());



            return rowView;
        }
      
}