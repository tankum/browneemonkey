package com.tp.brwnee;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by Tanay on 18/08/15.
 */
public class HistoryList extends Activity implements View.OnClickListener {

    ListView historyList;
    ImageButton goBack, clearHist;
    String childUnId, childAge, childName;
    TextView histAction, histActionSub, tempText;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.history_list);

        Bundle gotBasket = getIntent().getExtras();
        childUnId = gotBasket.getString("chUnId");
        childAge= gotBasket.getString("chAge");
        childName= gotBasket.getString("chName");

        histAction = (TextView) findViewById(R.id.tvHistAction);
        histActionSub = (TextView) findViewById(R.id.tvHistAction01);


        historyList= (ListView) findViewById(R.id.lvHistory);
        goBack =(ImageButton) findViewById(R.id.ibBack);
        clearHist = (ImageButton) findViewById(R.id.ibClearHist);

        goBack.setOnClickListener(this);
        clearHist.setOnClickListener(this);

        makeHistList();

    }

    private void makeHistList(){
        // Setting up the list of reasons
        childHistory cHist = new childHistory(this);

        cHist.open();
        Cursor r = cHist.readHistEntry();
        int n = r.getCount();
        cHist.close();

        if(n!=0){
            final MyAdapterHistory rAdapter = new MyAdapterHistory(this, generateHistData());
            historyList.setAdapter(rAdapter);
        }
    }

    private ArrayList<ItemHist> generateHistData() {
        // TODO Auto-generated method stub
        ArrayList<ItemHist> histItems = new ArrayList<ItemHist>();

        childHistory pHist = new childHistory(this);
        pHist.open();
        Cursor k = pHist.readHistEntry();
        int p = k.getCount();
        pHist.close();

        k.moveToFirst();

        if(p!=0){
            for (int i=0; i<p;i++){
                if(k.getString(2).equals(childUnId)){
                    histAction.setVisibility(View.GONE);
                    histActionSub.setVisibility(View.GONE);
                    histItems.add(new ItemHist(k.getString(3), k.getString(4), k.getString(5), k.getString(6)));

                }
                k.moveToNext();
            }
            Collections.reverse(histItems);
            return histItems;
        }else{
            //action.setText("You do not have any reasons added");
            return null;
        }

    }

    public void onClick(View v) {
        // TODO Auto-generated method stub
        switch(v.getId()) {

            case R.id.ibBack:

                Bundle basketHist = new Bundle();
                basketHist.putString("key", childUnId);
                basketHist.putString("name", childName);
                basketHist.putString("age", childAge);


                Intent m = new Intent(HistoryList.this, ChildDetails.class);
                m.putExtras(basketHist);
                startActivity(m);
                finish();
                break;

            case R.id.ibClearHist:
                childHistory clearAll = new childHistory(HistoryList.this);
                clearAll.open();
                clearAll.delete(childUnId);
                clearAll.close();


                historyList.setVisibility(View.GONE);
                histAction.setVisibility(View.VISIBLE);
                histActionSub.setVisibility(View.VISIBLE);
                break;

        }
    }

}
