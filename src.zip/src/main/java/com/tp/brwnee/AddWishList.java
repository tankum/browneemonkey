package com.tp.brwnee;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class AddWishList extends Activity implements OnClickListener{
	ImageButton addWish, clearWish, noWishes;
	TextView actionWish, actionWish01, pageTitle, pageSub, addWishTitle, modWishTitle;
	LinearLayout newWish, modWish;
	ListView listw, myReasons;
	
	Button cancelWish, submitWish, presetWish, modSubmit, modCancel;
	EditText reqPoints, wishName, wishPrice, modPoints, modName, modPrice, rowUnId;
	String childUnId, childAge, childName, fDate, fTime, fWeekDay, rowReason, rowPoints, rowPrice, rowId;
	FrameLayout overlayW;
	Integer childAgeNum, currentposition;
	ImageView brwneeMan;
	RelativeLayout pageBody;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_wish_list);

		Bundle gotBasket = getIntent().getExtras();
		childUnId = gotBasket.getString("chUnId");
		childAge= gotBasket.getString("chAge");
		childName= gotBasket.getString("chName");
		
		addWish = (ImageButton) findViewById(R.id.bAddWish);
		clearWish = (ImageButton) findViewById(R.id.bClearWish);
		actionWish = (TextView) findViewById(R.id.tvWishAction);
		actionWish01 = (TextView) findViewById(R.id.tvWishAction01);
		noWishes = (ImageButton) findViewById(R.id.bNoWishes);
		presetWish= (Button) findViewById(R.id.btnWishPresets);
		listw = (ListView) findViewById(R.id.lvWishes);
		brwneeMan = (ImageView) findViewById(R.id.imageView1);

		pageTitle = (TextView) findViewById(R.id.tvPage);
		pageSub =(TextView) findViewById(R.id.tvSubPage);
		pageBody = (RelativeLayout) findViewById(R.id.rlListContainer);

		overlayW = (FrameLayout) findViewById(R.id.flOverlayW);

		addWishTitle = (TextView) findViewById(R.id.tvAddWishTitle);
		newWish = (LinearLayout) findViewById(R.id.llNewWish);
		reqPoints = (EditText) findViewById(R.id.etReqPoints);
		wishName = (EditText) findViewById(R.id.etWish);
		wishPrice = (EditText) findViewById(R.id.etPrice);

		modWishTitle = (TextView) findViewById(R.id.tvModWishTitle);
		modWish = (LinearLayout) findViewById(R.id.llModWish);
		modPoints = (EditText) findViewById(R.id.etModReqPoints);
		modName = (EditText) findViewById(R.id.etModWish);
		modPrice = (EditText) findViewById(R.id.etModPrice);
		rowUnId = (EditText) findViewById(R.id.etRow);

		
		submitWish = (Button) findViewById(R.id.bSubmitWish);		
		cancelWish= (Button) findViewById(R.id.bCancelWish);

		modSubmit= (Button) findViewById(R.id.bModSubmitWish);
		modCancel = (Button) findViewById(R.id.bModCancelWish);

		Animation slideIn = AnimationUtils.loadAnimation(this, R.anim.slidedown_in_slow);
		brwneeMan.startAnimation(slideIn);
		brwneeMan.setVisibility(View.VISIBLE);

		Animation slideUpPage = AnimationUtils.loadAnimation(this, R.anim.slideup_bottom);
		pageBody.startAnimation(slideUpPage);

		Animation zoomOut = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		clearWish.startAnimation(zoomOut);
		addWish.startAnimation(zoomOut);

		Typeface custom_font01 = Typeface.createFromAsset(getAssets(), "fonts/Anton.ttf");
		pageTitle.setTypeface(custom_font01);
		presetWish.setTypeface(custom_font01);
		addWishTitle.setTypeface(custom_font01);
		modWishTitle.setTypeface(custom_font01);

		Typeface custom_font02 = Typeface.createFromAsset(getAssets(), "fonts/Copperplate.ttc");
		pageSub.setTypeface(custom_font02);

		Typeface custom_font03 = Typeface.createFromAsset(getAssets(), "fonts/IndieFlower.ttf");
		actionWish.setTypeface(custom_font03);

		addWish.setOnClickListener(this);
		submitWish.setOnClickListener(this);
		cancelWish.setOnClickListener(this);
		clearWish.setOnClickListener(this);
		noWishes.setOnClickListener(this);
		modSubmit.setOnClickListener(this);
		modCancel.setOnClickListener(this);
		presetWish.setOnClickListener(this);

		makeList();
		updateTime();

	}

	public void updateTime(){
		Calendar c = Calendar.getInstance();


		SimpleDateFormat df = new SimpleDateFormat("hh:mm aa");
		SimpleDateFormat ds = new SimpleDateFormat("dd-MM-yyyy");
		SimpleDateFormat sdf = new SimpleDateFormat("EEEE");

		String formattedTime = df.format(c.getTime());
		String formattedDate = ds.format(c.getTime());
		String formattedDay = sdf.format(c.getTime());

		fDate = formattedDate;
		fTime = formattedTime;
		fWeekDay = formattedDay;
	}

	private void makeList(){
		// Setting up the list of reasons
		WishList cWish = new WishList(this);

		cWish.open();
		Cursor r = cWish.readReasonEntry();
		int n = r.getCount();
		cWish.close();

		if(n!=0){
			final MyAdapterWish rAdapter = new MyAdapterWish(this, generateReasonData());
			myReasons = (ListView) findViewById(R.id.lvWishes);
			myReasons.setAdapter(rAdapter);
			registerForContextMenu(myReasons);

			//final SwipeDetector swipeDetector = new SwipeDetector();

			myReasons.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override

				public void onItemClick (AdapterView<?> parent, View view,int position, long id) {
					Context context = view.getContext();
					TextView wishItem = ((TextView) view.findViewById(R.id.tvdbReason));
					TextView wishId = ((TextView) view.findViewById(R.id.tvdbReasonRow));
					TextView pointWish = ((TextView) view.findViewById(R.id.tvdbPoints));
					TextView wishUrl = ((TextView) view.findViewById(R.id.tvdbUrl));

					// get the clicked item details
					String clWish = wishItem.getText().toString();
					String clWishId = wishId.getText().toString();
					String clWishPoints = pointWish.getText().toString();
					String clWishUrl = wishUrl.getText().toString();
					String rType = "Wish";
					String histDate = fDate + " | " + fTime + " | " + fWeekDay;

					Intent rWish = new Intent();
					Bundle wishBskt = new Bundle();
					wishBskt.putString("reqpnt", clWishPoints);
					wishBskt.putString("wishrsn", clWish);
					wishBskt.putString("wishUrl", clWish);

					childHistory hist = new childHistory(AddWishList.this);
					hist.open();
					hist.createHistEntry(childUnId, childName, histDate, clWish, rType, clWishPoints);
					hist.close();

					rWish.putExtras(wishBskt);
					setResult(RESULT_OK, rWish);
					finish();
				}
			});

		}
	}


	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
		if (v.getId()==R.id.lvWishes) {
			AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)menuInfo;
			currentposition = info.position;


			//menu.setHeaderTitle("Options");
			rowReason = ((TextView)info.targetView.findViewById(R.id.tvdbReason)).getText().toString();
			rowPoints = ((TextView)info.targetView.findViewById(R.id.tvdbPoints)).getText().toString();
			rowPrice = ((TextView)info.targetView.findViewById(R.id.tvdbPrice)).getText().toString();
			rowId = ((TextView)info.targetView.findViewById(R.id.tvdbReasonRow)).getText().toString();

			String[] menuItems = new String[] {"Edit","Delete"};
			for (int i = 0; i<menuItems.length; i++) {
				menu.add(Menu.NONE, i, i, menuItems[i]);
			}
		}
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
		int menuItemIndex = item.getItemId();
		String[] menuItems = new String[] {"Edit","Delete"};
		String menuItemName = menuItems[menuItemIndex];

		if (menuItemName == "Edit") {
			if(modWish.getVisibility() == View.VISIBLE){
				overlayW.setVisibility(View.GONE);
				Animation slideOut = AnimationUtils.loadAnimation(this, R.anim.slidedown_out);
				modWish.startAnimation(slideOut);
				modWish.setVisibility(View.GONE);

				modPoints.setText("");
				modName.setText("");
				modPrice.setText("");
				rowUnId.setText("");

			}else{
				overlayW.setVisibility(View.VISIBLE);
				Animation slideIn = AnimationUtils.loadAnimation(this, R.anim.slidedown_in);
				modWish.startAnimation(slideIn);
				modWish.setVisibility(View.VISIBLE);

				modPoints.setText(rowPoints);
				modName.setText(rowReason);
				modPrice.setText(rowPrice);
				rowUnId.setText(rowId);
			}
		}
		if (menuItemName == "Delete") {
			long lR = Long.parseLong(rowId);
			WishList delReason = new WishList(this);

			delReason.open();
			delReason.deleteEntry(lR);
			delReason.close();

			makeList();
		}

		return true;
	}
	

	private ArrayList<ItemWish> generateReasonData() {
		// TODO Auto-generated method stub
		ArrayList<ItemWish> wishItems = new ArrayList<ItemWish>();
		
		WishList lsWish = new WishList(this);
		lsWish.open();
		Cursor k = lsWish.readReasonEntry();
		int p = k.getCount();
		lsWish.close();
		
		k.moveToFirst();

		
		if(p!=0){
				for (int i=0; i<p;i++){
					if(k.getString(3).equals(childUnId)) {
						listw.setVisibility(View.VISIBLE);
						actionWish.setVisibility(View.GONE);
						actionWish01.setVisibility(View.GONE);
						presetWish.setVisibility(View.GONE);
						wishItems.add(new ItemWish(k.getString(1), k.getString(2), k.getString(0), k.getString(4), k.getString(5), k.getString(6)));

					}
					k.moveToNext();
				}				
				Collections.reverse(wishItems);
				return wishItems;			
		}else{
			listw.setVisibility(View.VISIBLE);
			return null;
		}
		
	}



	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){

		case R.id.btnWishPresets:
			listw.setVisibility(View.VISIBLE);

			try
			{
				//Load File
				childAgeNum = Integer.parseInt(childAge);

				if(childAgeNum>0 && childAgeNum <=5){
					//actionWish01.setVisibility(View.GONE);
					BufferedReader jsonReader = new BufferedReader(new InputStreamReader(this.getResources().openRawResource(R.raw.reasonearlywish)));
					StringBuilder jsonBuilder = new StringBuilder();
					for (String line = null; (line = jsonReader.readLine()) != null;) {
						jsonBuilder.append(line).append("\n");

					}
					//Parse Json
					JSONTokener tokener = new JSONTokener(jsonBuilder.toString());
					JSONArray jsonArray = new JSONArray(tokener);

					for (int index = 0; index < jsonArray.length(); index++) {
						//Set both values into the listview
						JSONObject jsonObject = jsonArray.getJSONObject(index);

						String psWish = jsonObject.getString("wish");
						String psPoints = jsonObject.getString("points");
						String psBrand = jsonObject.getString("brand");
						String psPrice = jsonObject.getString("price");
						String psUrl = jsonObject.getString("url");

						WishList preW = new WishList(AddWishList.this);
						preW.open();
						preW.createWishEntry(psWish, psPoints, childUnId, psBrand, psPrice, psUrl);
						preW.close();
					}

				}else if(childAgeNum>5 && childAgeNum <=9){
					//actionWish01.setVisibility(View.GONE);
					BufferedReader jsonReader = new BufferedReader(new InputStreamReader(this.getResources().openRawResource(R.raw.reasonmidwish)));
					StringBuilder jsonBuilder = new StringBuilder();
					for (String line = null; (line = jsonReader.readLine()) != null;) {
						jsonBuilder.append(line).append("\n");

					}
					//Parse Json
					JSONTokener tokener = new JSONTokener(jsonBuilder.toString());
					JSONArray jsonArray = new JSONArray(tokener);

					for (int index = 0; index < jsonArray.length(); index++) {
						//Set both values into the listview
						JSONObject jsonObject = jsonArray.getJSONObject(index);

						String psWish = jsonObject.getString("wish");
						String psPoints = jsonObject.getString("points");
						String psBrand = jsonObject.getString("brand");
						String psPrice = jsonObject.getString("price");
						String psUrl = jsonObject.getString("url");

						WishList preW = new WishList(AddWishList.this);
						preW.open();
						preW.createWishEntry(psWish, psPoints, childUnId, psBrand, psPrice, psUrl);
						preW.close();
					}

				}else if(childAgeNum>9 && childAgeNum <=14){
					actionWish01.setVisibility(View.GONE);
					BufferedReader jsonReader = new BufferedReader(new InputStreamReader(this.getResources().openRawResource(R.raw.reasonteenwish)));
					StringBuilder jsonBuilder = new StringBuilder();
					for (String line = null; (line = jsonReader.readLine()) != null;) {
						jsonBuilder.append(line).append("\n");

					}
					//Parse Json
					JSONTokener tokener = new JSONTokener(jsonBuilder.toString());
					JSONArray jsonArray = new JSONArray(tokener);

					for (int index = 0; index < jsonArray.length(); index++) {
						//Set both values into the listview
						JSONObject jsonObject = jsonArray.getJSONObject(index);

						String psWish = jsonObject.getString("wish");
						String psPoints = jsonObject.getString("points");
						String psBrand = jsonObject.getString("brand");
						String psPrice = jsonObject.getString("price");
						String psUrl = jsonObject.getString("url");

						WishList preW = new WishList(AddWishList.this);
						preW.open();
						preW.createWishEntry(psWish, psPoints, childUnId, psBrand, psPrice, psUrl);
						preW.close();
					}

				}else if(childAgeNum>14){
					//actionWish01.setVisibility(View.GONE);
					BufferedReader jsonReader = new BufferedReader(new InputStreamReader(this.getResources().openRawResource(R.raw.reasonhighwish)));
					StringBuilder jsonBuilder = new StringBuilder();
					for (String line = null; (line = jsonReader.readLine()) != null;) {
						jsonBuilder.append(line).append("\n");

					}
					//Parse Json
					JSONTokener tokener = new JSONTokener(jsonBuilder.toString());
					JSONArray jsonArray = new JSONArray(tokener);

					for (int index = 0; index < jsonArray.length(); index++) {
						//Set both values into the listview
						JSONObject jsonObject = jsonArray.getJSONObject(index);

						String psWish = jsonObject.getString("wish");
						String psPoints = jsonObject.getString("points");
						String psBrand = jsonObject.getString("brand");
						String psPrice = jsonObject.getString("price");
						String psUrl = jsonObject.getString("url");

						WishList preW = new WishList(AddWishList.this);
						preW.open();
						preW.createWishEntry(psWish, psPoints, childUnId, psBrand, psPrice, psUrl);
						preW.close();
					}

				}


			} catch (FileNotFoundException e) {
				Log.e("jsonFile", "file not found");

			} catch (IOException e) {
				Log.e("jsonFile", "ioerror");

			} catch (JSONException e) {
				e.printStackTrace();
			}

			makeList();

			break;

		case R.id.bAddWish:
			
			if(newWish.getVisibility() == View.VISIBLE){				
				overlayW.setVisibility(View.GONE);
				Animation slideOut = AnimationUtils.loadAnimation(this, R.anim.slidedown_out);
				newWish.startAnimation(slideOut);
				newWish.setVisibility(View.GONE);

			}else{
				overlayW.setVisibility(View.VISIBLE);
				Animation slideIn = AnimationUtils.loadAnimation(this, R.anim.slidedown_in);
				newWish.startAnimation(slideIn);
				newWish.setVisibility(View.VISIBLE);
			}
			
			/*Intent aR = new Intent(AddReasonList.this, AddPoints.class);
			startActivityForResult(aR,0);*/		
			break;
		
		case R.id.bClearWish:
			String reasonType = "Add";
			
			WishList clearAll = new WishList(AddWishList.this);
			clearAll.open();
			clearAll.deleteWish(childUnId);
			clearAll.close();
			

			listw.setVisibility(View.GONE);
			actionWish.setVisibility(View.VISIBLE);
			actionWish01.setVisibility(View.VISIBLE);
			presetWish.setVisibility(View.VISIBLE);

			break;
			
		case R.id.bNoWishes:
			Intent noBrwn = new Intent();
			setResult(RESULT_CANCELED, noBrwn);
			finish();
			break;
		
		case R.id.bSubmitWish:
			
			boolean wishAdded = true;

			if(isEmpty(wishName) || isEmpty(wishPrice) || isEmpty(reqPoints)){
				wishAdded=false;
				openAlert(v);
			}else{
				try {
					String rPoints = reqPoints.getText().toString();
					String wName = wishName.getText().toString();
					String wBrand = "self";
					String wPrice = wishPrice.getText().toString();
					String wUrl = "NA";
					String rType = "Wish";
					String histDate = fDate + " | " + fTime + " | " + fWeekDay;

					WishList newW = new WishList(AddWishList.this);
					newW.open();
					newW.createWishEntry(wName, rPoints, childUnId, wBrand, wPrice, wUrl);
					newW.close();

					childHistory hist = new childHistory(AddWishList.this);
					hist.open();
					hist.createHistEntry(childUnId, childName, histDate, wName, rType, rPoints);
					hist.close();

				} catch (Exception e) {
					wishAdded = false;
					String error = e.toString();
					Dialog d = new Dialog(this);
					d.setTitle("Sorry");
					TextView tv = new TextView(this);
					tv.setText(error);
					d.setContentView(tv);
					d.show();

				} finally {

					String rPoints = reqPoints.getText().toString();
					String wName = wishName.getText().toString();

					Intent addThis = new Intent();
					Bundle wishBskt = new Bundle();

					if (wName != null) {
						wishBskt.putString("wishrsn", wName);
					} else {
						wishBskt.putString("wishrsn", "No Wish mentioned");
					}

					if (rPoints != null) {
						wishBskt.putString("reqpnt", rPoints);
					} else {
						wishBskt.putString("reqpnt", "0");
					}


					addThis.putExtras(wishBskt);
					setResult(RESULT_OK, addThis);
					finish();
				}
			}



			break;
			
		case R.id.bCancelWish:
			overlayW.setVisibility(View.GONE);
			Animation slideOut = AnimationUtils.loadAnimation(this, R.anim.slidedown_out);
			newWish.startAnimation(slideOut);
			newWish.setVisibility(View.GONE);

			break;

			case R.id.bModSubmitWish:

				boolean modifyAdded = true;

				if (isEmpty(modName) || isEmpty(modPoints) || isEmpty(modPrice)) {
					modifyAdded = false;
					openAlert(v);
				}else{
					try{
						String wishPoints = modPoints.getText().toString();
						String wishReason = modName.getText().toString();
						String wishPrice = modPrice.getText().toString();
						String wBrand = "self";
						String wUrl = "NA";
						String rType = "Wish";
						long rUD= Long.parseLong(rowUnId.getText().toString());

						WishList newR = new WishList(AddWishList.this);
						newR.open();
						newR.modifyEntry(rUD, wishReason, wishPoints,childUnId, wBrand, wishPrice, wUrl);
						newR.close();

					}catch(Exception e){
						modifyAdded = false;
						String error=e.toString();
						Dialog d = new Dialog(this);
						d.setTitle("Sorry");
						TextView tv = new TextView(this);
						tv.setText(error);
						d.setContentView(tv);
						d.show();
					}finally{


						overlayW.setVisibility(View.GONE);
						Animation slideOutMod = AnimationUtils.loadAnimation(this, R.anim.slidedown_out);
						modWish.startAnimation(slideOutMod);
						modWish.setVisibility(View.GONE);

						View view = this.getCurrentFocus();
						if (view != null) {
							InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
							imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
						}

						makeList();
					}
				}

				break;

			case R.id.bModCancelWish:
				overlayW.setVisibility(View.GONE);
				Animation slideOutMod = AnimationUtils.loadAnimation(this, R.anim.slidedown_out);
				modWish.startAnimation(slideOutMod);
				modWish.setVisibility(View.GONE);
				break;
		}		
	}

	private void openAlert(View view) {
		// TODO Auto-generated method stub
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(AddWishList.this);


		// Get the layout inflater
		LayoutInflater inflater = AddWishList.this.getLayoutInflater();

		// Inflate and set the layout for the dialog
		// Pass null as the parent view because its going in the dialog layout
		alertDialogBuilder.setView(inflater.inflate(R.layout.alert_dialog, null));


		// set negative button: No message
		alertDialogBuilder.setNegativeButton("Oops!!!",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog,int id) {
				// cancel the alert box and put a Toast to the user
				dialog.cancel();
				Toast.makeText(getApplicationContext(), "Thanks for your patience.",
						Toast.LENGTH_LONG).show();
			}
		});



		AlertDialog alertDialog = alertDialogBuilder.create();
		// show alert
		alertDialog.show();
	}

	//checking for empty field
	private boolean isEmpty(EditText myeditText) {
		return myeditText.getText().toString().trim().length() == 0;
	}
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}
	
}
