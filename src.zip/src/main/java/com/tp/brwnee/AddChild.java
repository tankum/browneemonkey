package com.tp.brwnee;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class AddChild extends Activity implements OnClickListener, OnCheckedChangeListener{
	
	Button createChild, cancel;
	ImageButton photoButton;
	EditText childName, childAge, childPoints, parentEmail;
	RadioGroup childGender;
	String setGender, cPoints, childId, lReason, lPoints, wGoal, wPoints;
	Bitmap cPhoto;
	ImageView brwneeMan;
	TextView pageTitle,pageSub;
	RelativeLayout imageHold;
	ScrollView pageBody;
	 //TextView photoData;
	
    private ImageView childPhoto;
    private Uri picUri;
    
    private static final int CAMERA_REQUEST = 1;
	public static final int MEDIA_TYPE_IMAGE = 1;

	final int PIC_CROP = 12;
	
	static File mediaFile, sendFile;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_child);
		
		createChild = (Button) findViewById(R.id.bCreate);
		cancel = (Button) findViewById(R.id.bCancel);
		childName = (EditText) findViewById(R.id.etName);
		childAge = (EditText) findViewById(R.id.etAge);
		parentEmail = (EditText) findViewById(R.id.etEmail);
		childGender = (RadioGroup) findViewById(R.id.rgGender);
		childPhoto = (ImageView) findViewById(R.id.ivcPhoto);
		photoButton = (ImageButton) findViewById(R.id.bTakePhoto);
		brwneeMan = (ImageView) findViewById(R.id.imageView1);
		imageHold = (RelativeLayout) findViewById(R.id.rlImageHold);
		pageBody = (ScrollView) findViewById(R.id.svBody);

		pageTitle = (TextView) findViewById(R.id.tvPage);
		pageSub =(TextView) findViewById(R.id.tvSubPage);

		Animation slideUpPage = AnimationUtils.loadAnimation(this, R.anim.slideup_bottom);
		pageBody.startAnimation(slideUpPage);


		Animation zoomOut = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		photoButton.startAnimation(zoomOut);
		imageHold.startAnimation(zoomOut);

		childGender.setOnCheckedChangeListener(this);
		cancel.setOnClickListener(this);
		photoButton.setOnClickListener(this);
		createChild.setOnClickListener(this);

		Typeface custom_font01 = Typeface.createFromAsset(getAssets(), "fonts/Anton.ttf");
		pageTitle.setTypeface(custom_font01);

		Typeface custom_font02 = Typeface.createFromAsset(getAssets(), "fonts/Copperplate.ttc");
		pageSub.setTypeface(custom_font02);
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		switch(v.getId()){
		case R.id.bCreate:
			boolean didItWork = true;
			String cName = childName.getText().toString();
			String cAge = childAge.getText().toString();
			String pEmail = "notintherelease@later.com";
			
			if (isEmpty(childName) || isEmpty(childAge) || setGender==null) {
				didItWork = false;
				openAlert(v);
			}
			else{
				try{
					cPoints = "0";
					lReason = "You dont have any last reason";
					lPoints = "0";
					wGoal = "No goal Set";
					wPoints = "0";

					
					
					Brwnee cEntry = new Brwnee(AddChild.this);
					cEntry.open();
					cEntry.createEntry(cName, cAge, pEmail, setGender, cPoints, lReason, lPoints, cPhoto, wGoal, wPoints);
					cEntry.close();
					
				}catch(Exception e){
					didItWork = false;
					openAlert(v);

				}finally{
					if(didItWork){
						Intent i = new Intent("com.tp.brwnee.MAINACTIVITY");
						startActivity(i);
						finish();
					}
				}
			}
			break;
			
		case R.id.bCancel:
			Intent i = new Intent("com.tp.brwnee.MAINACTIVITY");
			startActivity(i);
			finish();
			break;		
			
		case R.id.bTakePhoto:
			Intent captureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

		    picUri = getOutputMediaFileUri(MEDIA_TYPE_IMAGE);

		    captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, picUri);

		    startActivityForResult(captureIntent, CAMERA_REQUEST);
			
		}		
	}
	
	private Uri getOutputMediaFileUri(int type) {
	    return Uri.fromFile(getOutputMediaFile(type));
	}
	
	private File getOutputMediaFile(int type) {

	    File mediaStorageDir = new File(
	            Environment.getExternalStorageDirectory(), "MyCameraApp");

	    if (!mediaStorageDir.exists()) {
	        if (!mediaStorageDir.mkdirs()) {
	            Log.d("MyCameraApp", "failed to create directory");
	            return null;
	        }
	    }

	    // Create a media file name
	    String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss")
	            .format(new Date());

	    if (type == MEDIA_TYPE_IMAGE) {
	        mediaFile = new File(mediaStorageDir.getPath() + File.separator
	                + "IMG_" + timeStamp + ".jpg");
	    } else {
	        return null;
	    }

	    return mediaFile;
	}


	 @Override
		public void onActivityResult(int requestCode, int resultCode, Intent data) {
		    // TODO Auto-generated method stub
		    super.onActivityResult(requestCode, resultCode, data);

		    if (requestCode == CAMERA_REQUEST) {
		        // if (Build.VERSION.SDK_INT < 19) {
		        try {
		            if (mediaFile.exists()) {
		                performCrop();
		                // new SavePhotoData().execute();
		            }

		        } catch (Exception e) {
		            // TODO: handle exception

		        }
		        // }

		    } else if (requestCode == 11) {

		        try {
		            picUri = data.getData();
		            Log.i("uri", "" + picUri);
		            performCrop();
		        } catch (Exception e) {
		            // TODO: handle exception

		        }

		    } else if (requestCode == PIC_CROP) {
		        // get the returned data

		        try {
		            Bundle extras = data.getExtras();

		            // get the cropped bitmap
		            cPhoto = extras.getParcelable("data");
		            // retrieve a reference to the ImageView
		            
		            // display the returned cropped image
		            childPhoto.setImageBitmap(cPhoto);

		            File mediaStorageDir = new File(
		                    Environment.getExternalStorageDirectory(),
		                    "MyCameraApp");

		            if (!mediaStorageDir.exists()) {
		                if (!mediaStorageDir.mkdirs()) {
		                    Log.d("MyCameraApp", "failed to create directory");

		                }
		            }

		            // Create a media file name
		            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss")
		                    .format(new Date());

		            sendFile = new File(mediaStorageDir.getPath() + File.separator
		                    + "IMG_" + timeStamp + ".png");

		            FileOutputStream fOut = new FileOutputStream(sendFile);

		            cPhoto.compress(Bitmap.CompressFormat.PNG, 85, fOut);
		            fOut.flush();
		            fOut.close();

		        } catch (Exception e) {
		            e.printStackTrace();

		        }
		    }

		    if (resultCode == 3) {
		        Bundle b = data.getExtras();
		        b.getString("msg");
		    }
		};



		private void performCrop() {
		    // take care of exceptions
		    try {
		        // call the standard crop action intent (the user device may not
		        // support it)
		        try {
		            Intent cropIntent = new Intent("com.android.camera.action.CROP");
		            // indicate image type and Uri
		            cropIntent.setDataAndType(picUri, "image/*");
		            // set crop properties
		            cropIntent.putExtra("crop", "true");
		            // indicate aspect of desired crop
		            cropIntent.putExtra("aspectX", 1);
		            cropIntent.putExtra("aspectY", 1);
		            // indicate output X and Y
		            cropIntent.putExtra("outputX", 256);
		            cropIntent.putExtra("outputY", 256);
		            // retrieve data on return
		            cropIntent.putExtra("return-data", true);
		            // start the activity - we handle returning in onActivityResult
		            startActivityForResult(cropIntent, PIC_CROP);
		        } catch (Exception e) {
		            // TODO: handle exception
		        }
		    }
		    // respond to users whose devices do not support the crop action
		    catch (ActivityNotFoundException anfe) {
		        // display an error message
		        String errorMessage = "Whoops - your device doesn't support the crop action!";
		        Toast toast = Toast.makeText(getApplicationContext(), errorMessage,
		                Toast.LENGTH_SHORT);
		        toast.show();
		    }
		}

	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {
		// TODO Auto-generated method stub
		switch(checkedId){
		case R.id.rFemale:
			setGender = "Female";
			break;
		case R.id.rMale:
			setGender = "Male";
			break;
		
		}
		
	}
	
	
	private void openAlert(View view) {
		// TODO Auto-generated method stub
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(AddChild.this);
		
		
		// Get the layout inflater
	    LayoutInflater inflater = AddChild.this.getLayoutInflater();

	    // Inflate and set the layout for the dialog
	    // Pass null as the parent view because its going in the dialog layout
	    alertDialogBuilder.setView(inflater.inflate(R.layout.alert_dialog, null));

		
         // set negative button: No message
         alertDialogBuilder.setNegativeButton("Oops!!!",new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog,int id) {
                    // cancel the alert box and put a Toast to the user
                    dialog.cancel();
                    Toast.makeText(getApplicationContext(), "Thanks for your patience.",
                            Toast.LENGTH_LONG).show();
                }
        });
		         
		         
			          
         AlertDialog alertDialog = alertDialogBuilder.create();
         // show alert
         alertDialog.show();
	}
	
	// validating email id
	private boolean isValidEmail(String email) {
		String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

		Pattern pattern = Pattern.compile(EMAIL_PATTERN);
		Matcher matcher = pattern.matcher(email);
		return matcher.matches();
	}
	
	//checking for empty field
	private boolean isEmpty(EditText myeditText) {
        return myeditText.getText().toString().trim().length() == 0;
    }

	

}
