package com.tp.brwnee;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class Splash extends Activity {

	ImageView red, blue, green;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash);

		red = (ImageView) findViewById(R.id.imageView1);
		blue = (ImageView) findViewById(R.id.imageView2);
		//green = (ImageView) findViewById(R.id.imageView3);

		Animation slideInSlow = AnimationUtils.loadAnimation(this, R.anim.slidedown_in_slow);
		Animation zoomOut = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		//Animation slideInSlowest = AnimationUtils.loadAnimation(this, R.anim.slidedown_in_slowest);

		red.startAnimation(slideInSlow);
		red.setVisibility(View.VISIBLE);

		blue.startAnimation(zoomOut);
		blue.setVisibility(View.VISIBLE);

		//green.startAnimation(slideInSlowest);
		//green.setVisibility(View.VISIBLE);
		
		Thread timer = new Thread(){
			@Override
			public void run(){
				try{
					sleep(3000);
				}catch (InterruptedException e){
					e.printStackTrace();
				}finally{
					Intent numPage = new Intent("com.tp.brwnee.MAINACTIVITY");
					startActivity(numPage);
				}
			}
		};
		
		timer.start();
	}
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}

}
