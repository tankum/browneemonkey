package com.tp.brwnee;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.RadioGroup.OnCheckedChangeListener;

public class ModifyChild extends Activity implements OnClickListener, OnCheckedChangeListener{
	
	Button saveChild, mCancel;
	EditText mChildName, mChildAge, mChildPoints, mParentEmail;
	RadioGroup mChildGender;
	RadioButton cMale,cFemale;
	String setGender, cPoints, childId, cName, cAge, cEmail, cGender;
	ImageButton changePhoto;
	Bitmap cPhoto;
	TextView curGend;
	
	long cR;
	private static final int CAMERA_REQUEST = 1888; 
    private ImageView getPhoto;
    private Uri picUri;
    final int PIC_CROP = 2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.modify_child);

		saveChild = (Button) findViewById(R.id.bmSave);
		mCancel = (Button) findViewById(R.id.bmCancel);
		mChildName = (EditText) findViewById(R.id.etmName);
		mChildAge = (EditText) findViewById(R.id.etmAge);
		mParentEmail = (EditText) findViewById(R.id.etmEmail);
		mChildGender = (RadioGroup) findViewById(R.id.rgmGender);
		cFemale = (RadioButton) findViewById(R.id.rmFemale);
		cMale = (RadioButton) findViewById(R.id.rmMale);
		getPhoto = (ImageView) findViewById(R.id.ivGetPhoto);
		changePhoto = (ImageButton) findViewById(R.id.bChangePhoto);
		curGend =(TextView) findViewById(R.id.tvGend);		
		mChildGender.clearCheck();
		
		Bundle gotChild = getIntent().getExtras();
		childId = gotChild.getString("keyId");
		cR = Long.parseLong(childId);
		
		Brwnee getC = new Brwnee(this);
		getC.open();
		Cursor ch = getC.readEntry();
		int rowC = ch.getCount();
		ch.moveToFirst();
		
		cName ="";
		cAge = "";
		cEmail = "";
		cGender = "";
		
		for(int i = 0; i<rowC; i++){
			
			if(Integer.parseInt(childId) == Integer.parseInt(ch.getString(0))){
				cName = ch.getString(1);
				cAge = ch.getString(3);
				cGender = ch.getString(4);
				cEmail = ch.getString(5);
				
				
				byte[] imgChild = ch.getBlob(8);
				Bitmap rndPhoto =  BitmapFactory.decodeByteArray(imgChild, 0, imgChild.length);
				
				Bitmap resized = Bitmap.createScaledBitmap(rndPhoto, 300, 300, true);
			    cPhoto = resized;
				
				ch.moveToNext();
			}
			else{
				ch.moveToNext();
			}
			
		}
		
		mChildName.setText(cName);
		mChildAge.setText(cAge);
		mParentEmail.setText(cEmail);
		getPhoto.setImageBitmap(cPhoto);
		
	if(cGender.equals("Female")){
			mChildGender.check(R.id.rmFemale);
			curGend.setText(cGender);
		}else if(cGender.equals("Male")){
			mChildGender.check(R.id.rmMale);
			curGend.setText(cGender);
		}
		
		getC.close();
		
		mChildGender.setOnCheckedChangeListener(this);
		saveChild.setOnClickListener(this);
		mCancel.setOnClickListener(this);
		changePhoto.setOnClickListener(this);
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		switch(v.getId()){
		case R.id.bmSave:
			boolean didItWork = true;
			
			try{
				String cName = mChildName.getText().toString();
				String cAge = mChildAge.getText().toString();
				String pEmail = mParentEmail.getText().toString();
				
				
				if(mChildGender.getCheckedRadioButtonId()!=-1){		
				    cGender = curGend.getText().toString();				    
				}
								
				Brwnee cEntry = new Brwnee(ModifyChild.this);
				cEntry.open();
				cEntry.modifyEntry(cR, cName, cAge, pEmail, cGender, cPhoto);
				cEntry.close();
				
			}catch(Exception e){
				didItWork = false;
				String error=e.toString();
				Dialog d = new Dialog(this);
				d.setTitle("Sorry");
				TextView tv = new TextView(this);
				tv.setText(error);
				d.setContentView(tv);
				d.show();
			}finally{
				if(didItWork){
					/*Intent i = new Intent("com.tp.brwnee.MAINACTIVITY");
					startActivity(i);
					finish();*/
					Intent l = new Intent(ModifyChild.this, ChildDetails.class);
					l.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
					startActivity(l);
					finish();
				}
			}
			
			
			break;
			
		case R.id.bmCancel:
			Intent i = new Intent(ModifyChild.this, ChildDetails.class);
			i.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
			startActivity(i);
			finish();
			break;
			
		case R.id.bChangePhoto:
			Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE); 
	        startActivityForResult(cameraIntent, CAMERA_REQUEST); 
			break;
		}
		
	
		
	}
	
	
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {  
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {  
            picUri = data.getData();
            performCrop();
        } 
        
        else if(requestCode == PIC_CROP){
        	//get the returned data
        	Bundle extras = data.getExtras();
        	//get the cropped bitmap
        	cPhoto = extras.getParcelable("data"); 

            getPhoto.setImageBitmap(cPhoto);
        	
        }
    } 

	private void performCrop() {
		// TODO Auto-generated method stub
		
		try {
			 //call the standard crop action intent (the user device may not support it)
			Intent cropIntent = new Intent("com.android.camera.action.CROP");
			    //indicate image type and Uri
			cropIntent.setDataAndType(picUri, "image/*");
			    //set crop properties
			cropIntent.putExtra("crop", "true");
			    //indicate aspect of desired crop
			cropIntent.putExtra("aspectX", 1);
			cropIntent.putExtra("aspectY", 1);
			    //indicate output X and Y
			cropIntent.putExtra("outputX", 256);
			cropIntent.putExtra("outputY", 256);
			    //retrieve data on return
			cropIntent.putExtra("return-data", true);
			    //start the activity - we handle returning in onActivityResult
			startActivityForResult(cropIntent, PIC_CROP);
		}
		catch(ActivityNotFoundException anfe){
		    //display an error message
		    String errorMessage = "Whoops - your device doesn't support the crop action!";
		    Toast toast = Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT);
		    toast.show();
		}
		
	}


	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {
		// TODO Auto-generated method stub
		switch(checkedId){
		case R.id.rmFemale:
			setGender = "Female";
			curGend.setText(setGender);
			break;
		case R.id.rmMale:
			setGender = "Male";
			curGend.setText(setGender);
			break;
		
		}
		
	}
	

}
