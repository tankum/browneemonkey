package com.tp.brwnee;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MyAdapterHistory extends ArrayAdapter<ItemHist>{

        private final Context context;
        private final ArrayList<ItemHist> itemsArrayList;

        public MyAdapterHistory(Context context, ArrayList<ItemHist> itemsArrayList) {

            super(context, R.layout.history_row, itemsArrayList);
 
            this.context = context;
            this.itemsArrayList = itemsArrayList;
        }
 
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
 
            // 1. Create inflater
            LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
 
            // 2. Get rowView from inflater
            View rowView = inflater.inflate(R.layout.history_row, parent, false);
 
            // 3. Get the two text view from the rowView
            TextView date = (TextView) rowView.findViewById(R.id.tvdbHistDate);
            TextView reason = (TextView) rowView.findViewById(R.id.tvdbHistActivity);
            TextView points = (TextView) rowView.findViewById(R.id.tvdbHistPoints);
            TextView type = (TextView) rowView.findViewById(R.id.tvdbHistType);
            ImageView actMark = (ImageView) rowView.findViewById(R.id.ivActMark);

            // 4. Set the text for textView
            date.setText(itemsArrayList.get(position).gethistDate());
            reason.setText(itemsArrayList.get(position).gethistActivity());
            points.setText(itemsArrayList.get(position).gethistPoints());
            type.setText(itemsArrayList.get(position).gethistType());

            String mrk = (String) itemsArrayList.get(position).gethistType();


            if(mrk.equals("Add")){
                actMark.setImageResource(R.drawable.btn_add);
            }
            if(mrk.equals("Sub")){
                actMark.setImageResource(R.drawable.btn_subtract);
            }
            if(mrk.equals("Wish")){
                actMark.setImageResource(R.drawable.btn_gift);
            }


            return rowView;
        }
      
}