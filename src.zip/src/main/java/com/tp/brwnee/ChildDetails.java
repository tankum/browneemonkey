package com.tp.brwnee;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Random;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.PorterDuff.Mode;
import android.opengl.Visibility;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

public class ChildDetails extends Activity implements OnClickListener{
	
	TextView chName, chPoints, lastPoints, lastReason, currentWish, reqWishPoints, chAgeDet;
	String chId, chNm, fName, fPoints, lstRsn, lstPnts, cGoal, goalPnts, fAge, chAge;
	ImageButton addPoints, subtractPoints, childList, cModify, cDelete, setWish, chOverflow, closeOverlay, historyBut, setWish01;
	ImageView childPhoto;
	Bitmap cPhoto;
	RelativeLayout page, wishMark;
	LinearLayout editOverlay, lastReasonBg, cW;
	FrameLayout editOverlayBg;
	View wishBg, wishLine;
	Button redeem;
	int myWidth, parentWidth, brwnDiff;
	final Context context = this;
	
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.child_details);
		
		Bundle gotBasket = getIntent().getExtras();
		
		chId = gotBasket.getString("key");
		chNm = gotBasket.getString("name");
		chAge = gotBasket.getString("age");

		chName = (TextView) findViewById(R.id.tvName);
		chPoints = (TextView) findViewById(R.id.tvPoints);
		childList = (ImageButton) findViewById(R.id.bChList);
		cModify = (ImageButton) findViewById(R.id.bModify);
		cDelete = (ImageButton) findViewById(R.id.bDelete);
		addPoints = (ImageButton) findViewById(R.id.bAddPoints);
		subtractPoints = (ImageButton) findViewById(R.id.bSubtractPoints);
		lastReason = (TextView) findViewById(R.id.tvLastReason);
		lastPoints = (TextView) findViewById(R.id.tvLastPoints);
		childPhoto = (ImageView) findViewById(R.id.ivChild);
		page = (RelativeLayout) findViewById(R.id.ll);
		editOverlay = (LinearLayout) findViewById(R.id.llEditChild);
		editOverlayBg = (FrameLayout) findViewById(R.id.flOverlay);
		chOverflow=(ImageButton) findViewById(R.id.bChOverflow);
		closeOverlay=(ImageButton) findViewById(R.id.bClose);
		wishBg=(View) findViewById(R.id.vWishLineBg);
		wishLine = (View) findViewById(R.id.vWishLine);
		lastReasonBg=(LinearLayout) findViewById(R.id.llLastReason);
		historyBut = (ImageButton) findViewById(R.id.bHistory);
		redeem = (Button) findViewById(R.id.bRedeem);
		chAgeDet=(TextView) findViewById(R.id.tvAge);

		cW = (LinearLayout) findViewById(R.id.llCurentWish);
		wishMark = (RelativeLayout) findViewById(R.id.rlWishMarker);


		setWish = (ImageButton) findViewById(R.id.bSetWish);
		//setWish01 = (ImageButton) findViewById(R.id.bSetWish01);
		currentWish = (TextView) findViewById(R.id.tvCurrentWish);
		reqWishPoints = (TextView) findViewById(R.id.tvWishPoints);
		
		addPoints.setOnClickListener(this);
		subtractPoints.setOnClickListener(this);
		childList.setOnClickListener(this);
		cModify.setOnClickListener(this);
		cDelete.setOnClickListener(this);
		setWish.setOnClickListener(this);
		chOverflow.setOnClickListener(this);
		closeOverlay.setOnClickListener(this);
		historyBut.setOnClickListener(this);
		redeem.setOnClickListener(this);

		fName = "";
		fPoints = "";
		lstRsn = "";
		lstPnts="";
		
		
		Brwnee thisChild = new Brwnee(this);
		
		thisChild.open();
		Cursor ch = thisChild.readEntry();
		int rows = ch.getCount();
		ch.moveToFirst();
		
		for(int i = 0; i<rows; i++){
			
			if(Integer.parseInt(chId) == Integer.parseInt(ch.getString(0))){
				fName = ch.getString(1);
				fPoints = ch.getString(2);
				fAge = ch.getString(3);
				lstRsn = ch.getString(6);
				lstPnts = ch.getString(7);
				cGoal = ch.getString(9);
				goalPnts = ch.getString(10);
				
				byte[] imgChild = ch.getBlob(8);
				Bitmap rndPhoto =  BitmapFactory.decodeByteArray(imgChild, 0, imgChild.length);
				
				 Bitmap resized = Bitmap.createScaledBitmap(rndPhoto, 300, 300, true);
			     cPhoto = resized;
			     
			     brwnDiff = (Integer.parseInt(goalPnts))-(Integer.parseInt(fPoints));
				
				ch.moveToNext();

				
				
			}
			else{
				ch.moveToNext();
			}
			
		}
		
		chPoints.setText(fPoints);
		chName.setText(fName);
		lastReason.setText(lstRsn);
		lastPoints.setText(lstPnts);
		childPhoto.setImageBitmap(cPhoto);
		currentWish.setText(cGoal);
		reqWishPoints.setText(brwnDiff +" brownees required");
		chAgeDet.setText(chAge.toUpperCase());

		thisChild.close();

	}
	
	
	@Override
    public void onWindowFocusChanged(boolean hasFocus) {
        // TODO Auto-generated method stub
        super.onWindowFocusChanged(hasFocus);
        updateSizeInfo();
    }
	 private void updateSizeInfo() {
		 int w = wishBg.getWidth();
		 int h = wishLine.getHeight();
		 
		 int numer =(Integer.parseInt(fPoints)); 
		 int denom =(Integer.parseInt(goalPnts));
		 
		 
		 if(denom==0){
			 currentWish.setText("+ add a wish");
			 LayoutParams paramImage = new RelativeLayout.LayoutParams(0, h);
			 wishLine.setLayoutParams(paramImage);
			 wishMark.setVisibility(View.GONE);
			 reqWishPoints.setVisibility(View.GONE);
			 redeem.setVisibility(View.GONE);
		 }else if (numer >= denom){
			 reqWishPoints.setVisibility(View.GONE);
			 wishMark.setVisibility(View.GONE);
			 redeem.setVisibility(View.VISIBLE);
		 }
		 else{
			 reqWishPoints.setVisibility(View.VISIBLE);
			 wishMark.setVisibility(View.VISIBLE);
			 double multFact = (numer * 100)/denom;
			 double nW = (w * multFact)/100;
			 LayoutParams paramImage = new RelativeLayout.LayoutParams((int) nW, h);
			 wishLine.setLayoutParams(paramImage);
			 redeem.setVisibility(View.GONE);
		 }
		 
	}
	
	@SuppressWarnings("deprecation")
	public static Bitmap getRoundedRectBitmap(Bitmap bitmap, int pixels) {
	    Bitmap result = null;
	    try {
	        result = Bitmap.createBitmap(300, 300, Bitmap.Config.ARGB_8888);
	        Canvas canvas = new Canvas(result);

	        int color = 0xff424242;
	        Paint paint = new Paint();
	        Rect rect = new Rect(0, 0, 300, 300);

	        paint.setAntiAlias(true);
	        canvas.drawARGB(0, 0, 0, 0);
	        paint.setColor(color); 
	        canvas.drawCircle(150, 150, 150, paint);
	        paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
	        canvas.drawBitmap(bitmap, rect, rect, paint);

	    } catch (NullPointerException e) {
	    } catch (OutOfMemoryError o) {
	    }
	    return result;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){

		case R.id.bAddPoints:
			Bundle basket = new Bundle();
			basket.putString("chUnId", chId);
			basket.putString("chAge", fAge);
			basket.putString("chName", chNm);

			Intent a = new Intent(ChildDetails.this, AddReasonList.class);
			a.putExtras(basket);
			startActivityForResult(a, 0);
			break;
		
		case R.id.bSubtractPoints:
			openAlert(v);
			break;
			
		case R.id.bSetWish:
			Bundle basketWish = new Bundle();
			basketWish.putString("chUnId", chId);
			basketWish.putString("chAge", fAge);
			basketWish.putString("chName", chNm);

			Intent k = new Intent(ChildDetails.this, AddWishList.class);
			k.putExtras(basketWish);
			startActivityForResult(k, 2);
			break;

		case R.id.bHistory:
			Bundle basketHist = new Bundle();
			basketHist.putString("chUnId", chId);
			basketHist.putString("chAge", chAge);
			basketHist.putString("chName", chNm);

			Intent m = new Intent(ChildDetails.this, HistoryList.class);
			m.putExtras(basketHist);
			startActivity(m);
			finish();
			break;

		case R.id.bRedeem:

			openRedeem(v);

			break;
				
		case R.id.bChList:
			Intent l = new Intent(ChildDetails.this, MainActivity.class);
			l.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
			startActivity(l);
			finish();
			break;
			
		case R.id.bChOverflow:
			if(editOverlay.getVisibility() == View.VISIBLE){
				editOverlayBg.setVisibility(View.GONE);
				Animation slideOut = AnimationUtils.loadAnimation(this, R.anim.slidedown_out);
				editOverlay.startAnimation(slideOut);
				editOverlay.setVisibility(View.GONE);
				
			}else{
				editOverlayBg.setVisibility(View.VISIBLE);
				Animation slideIn = AnimationUtils.loadAnimation(this, R.anim.slidedown_in);
				editOverlay.startAnimation(slideIn);
				editOverlay.setVisibility(View.VISIBLE);
				
			}
			break;
			
		case R.id.bClose:
			editOverlayBg.setVisibility(View.GONE);
			Animation slideOut = AnimationUtils.loadAnimation(this, R.anim.slidedown_out);
			editOverlay.startAnimation(slideOut);
			editOverlay.setVisibility(View.GONE);
			break;
			
		case R.id.bModify:
			Bundle modC = new Bundle();
			modC.putString("keyId", chId);			
			Intent cM = new Intent("com.tp.brwnee.MODIFYCHILD");
			cM.putExtras(modC);
			startActivity(cM);

			break;
			
		case R.id.bDelete:
			boolean deleted = true;
			try{
				long lR = Long.parseLong(chId);
				Brwnee delC = new Brwnee(this);
				
				delC.open();
				delC.deleteEntry(lR);
				delC.close();
				
				Intent j = new Intent(ChildDetails.this, MainActivity.class);
				j.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
				startActivity(j);
				finish();
				
			}catch(Exception e){
				deleted=false;
				String error=e.toString();
				Dialog d = new Dialog(this);
				d.setTitle("Sorry could not delete");
				TextView tv = new TextView(this);
				tv.setText(error);
				d.setContentView(tv);
				d.show();
			}
			break;
		}
		
		
	}
	
	public String loadJSONFromAsset() {
	    String json = null;
	    try {

	        InputStream is = getAssets().open("tasks.json");

	        int size = is.available();

	        byte[] buffer = new byte[size];

	        is.read(buffer);

	        is.close();

	        json = new String(buffer, "UTF-8");


	    } catch (IOException ex) {
	        ex.printStackTrace();
	        return null;
	    }
	    return json;

	}

	private void openRedeem(View view){
		// TODO Auto-generated method stub
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ChildDetails.this);
		// Get the layout inflater
		LayoutInflater inflater = ChildDetails.this.getLayoutInflater();
		// Pass null as the parent view because its going in the dialog layout
		View layout = inflater.inflate(R.layout.redeem_dialog,null);
		alertDialogBuilder.setView(layout);

		// set positive button: Yes message
		alertDialogBuilder.setPositiveButton("Redeem",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog,int id) {
				long lRow = Long.parseLong(chId);
				int goalPnt =(Integer.parseInt(goalPnts));
				String newPoints = chPoints.getText().toString();

				redeem.setVisibility(View.GONE);

				int finalPnts = (Integer.parseInt(newPoints))-goalPnt;

				chPoints.setText("" + finalPnts);

				Brwnee npData = new Brwnee(ChildDetails.this);
				npData.open();
				npData.updateFinalBrwn(lRow, finalPnts);
				npData.close();


				String wr = "empty";
				String wp = "0";

				long wishRow = Long.parseLong(chId);

				Brwnee nwWish = new Brwnee(ChildDetails.this);
				nwWish.open();
				nwWish.updateGoal(wishRow, wp, wr);
				nwWish.close();

				dialog.cancel();

				currentWish.setText("+ add a wish");
				wishMark.setVisibility(View.GONE);
				reqWishPoints.setVisibility(View.GONE);
				redeem.setVisibility(View.GONE);

				Toast.makeText(getApplicationContext(), "Great Job kid",
						Toast.LENGTH_LONG).show();



			}

		});
		// set negative button: No message
		alertDialogBuilder.setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog,int id) {
				// cancel the alert box and put a Toast to the user
				dialog.cancel();
				Toast.makeText(getApplicationContext(), "Seems you want to save your brownees",
						Toast.LENGTH_LONG).show();
			}
		});


		AlertDialog alertDialog = alertDialogBuilder.create();

		// show alert
		alertDialog.show();
	}
	
	private void openAlert(View view) {
		// TODO Auto-generated method stub
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ChildDetails.this); 
		// Get the layout inflater
	    LayoutInflater inflater = ChildDetails.this.getLayoutInflater();
	    // Pass null as the parent view because its going in the dialog layout
	    View layout = inflater.inflate(R.layout.subtract_dialog,null);
	    alertDialogBuilder.setView(layout);

		try {
			JSONObject obj = new JSONObject(loadJSONFromAsset());
			JSONArray m_jArry = obj.getJSONArray("tasks");
			
			Random crazyNum = new Random();
			int r = crazyNum.nextInt(m_jArry.length()-1);
			
			JSONObject jo_inside = m_jArry.getJSONObject(r); 
			String task_value = jo_inside.getString("task");
			
			TextView taskIdea = (TextView) layout.findViewById(R.id.tvTaskIdea);
	   	    taskIdea.setText(task_value);
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    

	    
	    
		// set positive button: Yes message
		alertDialogBuilder.setPositiveButton("Subtract",new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog,int id) {
						Bundle basketSub = new Bundle();
						basketSub.putString("chUnId", chId);
						basketSub.putString("chAge", fAge);
						basketSub.putString("chName", chNm);
	                    // go to a new activity of the app
						Intent p = new Intent(ChildDetails.this, SubtractReasonList.class);
						p.putExtras(basketSub);
						startActivityForResult(p, 1);
	                }
	              });
         // set negative button: No message
         alertDialogBuilder.setNegativeButton("Seems Fine",new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog,int id) {
                    // cancel the alert box and put a Toast to the user
                    dialog.cancel();
                    Toast.makeText(getApplicationContext(), "Good Appreciate your effort",
                    Toast.LENGTH_LONG).show();
                }
        });
		         
   
         AlertDialog alertDialog = alertDialogBuilder.create();

         // show alert
         alertDialog.show();

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if(resultCode==RESULT_OK){
			switch(requestCode){
			case 0:

					String newPoints = chPoints.getText().toString();
					
					Bundle basket = data.getExtras();
					String p = basket.getString("pnt");
					String r = basket.getString("rsn");
					String t = "Add";
					
					int finalPnts = Integer.parseInt(newPoints) + Integer.parseInt(p);
					long lRow = Long.parseLong(chId);

					
					chPoints.setText(""+finalPnts);
					lastReason.setText(r);
					lastPoints.setText("+" + p);
					lastReasonBg.setBackgroundResource(R.drawable.bg_rounded_green);
					
					//lastReasonBg.setBackgroundResource(R.drawable.bg_rounded_green);
					
					Brwnee nwData = new Brwnee(this);
					nwData.open();
					nwData.updateEntry(lRow, finalPnts, r, p, t);
					nwData.close();
				
				break;
			case 1:

					String snewPoints = chPoints.getText().toString();
					
					Bundle sbasket = data.getExtras();
					String sp = sbasket.getString("spnt");
					String sr = sbasket.getString("srsn");
					String st = "Sub";
					
					int sfinalPnts = Integer.parseInt(snewPoints) - Integer.parseInt(sp);
					long slRow = Long.parseLong(chId);
					
					/*Dialog d1 = new Dialog(this);
					d1.setTitle("alert");
					TextView tv1 = new TextView(this);
					tv1.setText(sp);
					d1.setContentView(tv1);
					d1.show();*/
					
					chPoints.setText(""+sfinalPnts);
					lastReason.setText(sr);
					lastPoints.setText("-" + sp);
					lastReasonBg.setBackgroundResource(R.drawable.bg_rounded_red);

				//lastReasonBg.setBackgroundResource(R.drawable.bg_rounded_red);
					
					Brwnee snwData = new Brwnee(this);
					snwData.open();
					snwData.updateEntry(slRow, sfinalPnts, sr, sp, st);
					snwData.close();
			
				break;
				
			case 2:	
				Bundle wbasket = data.getExtras();
				String wr = wbasket.getString("wishrsn");
				String wp = wbasket.getString("reqpnt");
				
				long wishRow = Long.parseLong(chId);

				currentWish.setText(wr);
				reqWishPoints.setText(wp);
				
				Brwnee nwWish = new Brwnee(this);
				nwWish.open();
				nwWish.updateGoal(wishRow, wp, wr);
				nwWish.close();
				
				

			break;
			}
		}else if(resultCode == RESULT_CANCELED){
			Toast.makeText(getApplicationContext(), "Good work. Appreciate your effort.", Toast.LENGTH_SHORT).show();
		}
		
		
	}
	
	@Override
	protected void onResume() {

	   super.onResume();
	   this.onCreate(null);
	}

}
