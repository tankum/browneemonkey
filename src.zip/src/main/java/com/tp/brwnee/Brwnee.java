package com.tp.brwnee;

import java.io.ByteArrayOutputStream;

import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;

public class Brwnee {
	
	public static final String KEY_ROWID = "_id";
	public static final String KEY_CHILDNAME = "child_name";
	public static final String KEY_POINTS = "brwnee_points";	
	public static final String KEY_AGE = "child_age";
	public static final String KEY_GENDER = "child_gender";
	public static final String KEY_EMAIL = "parent_email";
	public static final String KEY_LASTREASON = "last_reason";
	public static final String KEY_LASTPOINTS = "last_points";
	public static final String KEY_PHOTO = "child_photo";
	public static final String KEY_GOAL = "_goal";
	public static final String KEY_GOALPOINTS = "goal_points";
	public static final String KEY_LASTRSNTYPE = "reason_type";
	
	
	private static final String DATABASE_NAME = "brwneedb";
	private static final String DATABASE_TABLE = "childTable";
	private static final int DATABASE_VERSION = 1;
	
	private DbHelper ourHelper;
	private Context ourContext;
	private SQLiteDatabase ourDatabase;
	
	private class DbHelper extends SQLiteOpenHelper{

		public DbHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL("CREATE TABLE " + DATABASE_TABLE + " ("+
					KEY_ROWID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
					KEY_CHILDNAME + " TEXT NOT NULL, " +
					KEY_POINTS + " TEXT NOT NULL, " +
					KEY_AGE + " TEXT NOT NULL, " +
					KEY_GENDER + " TEXT NOT NULL, " +
					KEY_EMAIL + " TEXT NOT NULL, " +
					KEY_LASTREASON + " TEXT NOT NULL, " +
					KEY_LASTPOINTS + " TEXT NOT NULL, " +
					KEY_PHOTO + " TEXT NOT NULL, " +
					KEY_GOAL + " TEXT NOT NULL, " +
					KEY_GOALPOINTS + " TEXT NOT NULL, " +
					KEY_LASTRSNTYPE + " TEXT NOT NULL);"
					);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);

		}

	}
	
	public Brwnee(Context c){
		ourContext = c;
	}
	
	public Brwnee open() throws SQLException{
		ourHelper = new DbHelper(ourContext);
		ourDatabase = ourHelper.getWritableDatabase();	
		return this;
	}
	
	public void close(){
		ourHelper.close();
	}

	public long createEntry(String cName, String cAge, String pEmail, String setGender, String cPoints, String lReason, String lPoints, Bitmap cPhoto, String wGoal, String wPoints) {
		// TODO Auto-generated method stub
		
		byte[] imgData = getBitmapAsByteArray(cPhoto);
		
		ContentValues cv = new ContentValues();
		cv.put(KEY_CHILDNAME, cName);
		cv.put(KEY_POINTS, cPoints);
		cv.put(KEY_AGE, cAge);
		cv.put(KEY_GENDER, setGender);
		cv.put(KEY_EMAIL, pEmail);
		cv.put(KEY_LASTREASON, lReason);
		cv.put(KEY_LASTPOINTS, lPoints);
		cv.put(KEY_PHOTO, imgData);
		cv.put(KEY_GOAL, wGoal);
		cv.put(KEY_GOALPOINTS, wPoints);
		cv.put(KEY_LASTRSNTYPE, wPoints);


		return ourDatabase.insert(DATABASE_TABLE, null, cv);
	}

	private byte[] getBitmapAsByteArray(Bitmap cPhoto) {
		// TODO Auto-generated method stub
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	    cPhoto.compress(CompressFormat.PNG, 0, outputStream);       
	    return outputStream.toByteArray();
	
	}

	public Cursor readEntry() {
		// TODO Auto-generated method stub
		String[] columns = new String[]{KEY_ROWID, KEY_CHILDNAME, KEY_POINTS, KEY_AGE, KEY_GENDER, KEY_EMAIL, KEY_LASTREASON, KEY_LASTPOINTS, KEY_PHOTO, KEY_GOAL, KEY_GOALPOINTS, KEY_LASTRSNTYPE};
		Cursor c = ourDatabase.query(DATABASE_TABLE, columns, null, null, null, null, null);
		if (c != null) {
			   c.moveToFirst();
			  }
			  return c;
	}

	public void updateEntry(long lRow, int finalPnts, String r, String p, String t) {
		// TODO Auto-generated method stub
		
		ContentValues cvUpdate = new ContentValues();
		cvUpdate.put(KEY_POINTS, finalPnts);
		cvUpdate.put(KEY_LASTREASON, r);
		cvUpdate.put(KEY_LASTPOINTS, p);
		cvUpdate.put(KEY_LASTRSNTYPE, p);
		ourDatabase.update(DATABASE_TABLE, cvUpdate, KEY_ROWID + "=" + lRow, null);	
	}

	public void updateFinalBrwn(long lRow, int finalPnts){
		ContentValues cvUpdate = new ContentValues();
		cvUpdate.put(KEY_POINTS, finalPnts);
		ourDatabase.update(DATABASE_TABLE, cvUpdate, KEY_ROWID + "=" + lRow, null);
	}
	
	public void updateGoal(long wRow, String goalPnts, String w){
		ContentValues wUpdate = new ContentValues();
		wUpdate.put(KEY_GOAL, w);
		wUpdate.put(KEY_GOALPOINTS, goalPnts);
		ourDatabase.update(DATABASE_TABLE, wUpdate, KEY_ROWID + "=" + wRow, null);
	}


	public void deleteEntry(long lR) {
		// TODO Auto-generated method stub
		ourDatabase.delete(DATABASE_TABLE, KEY_ROWID + "=" + lR, null);
	}

	

	public void modifyEntry(long cR, String cName, String cAge, String pEmail, String setGender, Bitmap cPhoto) {
		// TODO Auto-generated method stub
		byte[] imgData = getBitmapAsByteArray(cPhoto);
		
		ContentValues cvUpdate = new ContentValues();
		cvUpdate.put(KEY_CHILDNAME, cName);
		cvUpdate.put(KEY_AGE, cAge);
		cvUpdate.put(KEY_EMAIL, pEmail);
		cvUpdate.put(KEY_GENDER, setGender);
		cvUpdate.put(KEY_PHOTO, imgData);
		
		ourDatabase.update(DATABASE_TABLE, cvUpdate, KEY_ROWID + "=" + cR, null);
		
	}


	
}
