package com.tp.brwnee;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class CreateReasons extends Activity{

	TextView testText;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reasons);
		
		View linearLayout = findViewById(R.id.rsnsView);
		testText = (TextView) findViewById(R.id.textView1);
		
		try
		{
		//Load File
		BufferedReader jsonReader = new BufferedReader(new InputStreamReader(this.getResources().openRawResource(R.raw.reasonsearly)));
		StringBuilder jsonBuilder = new StringBuilder();
		for (String line = null; (line = jsonReader.readLine()) != null;) {
		jsonBuilder.append(line).append("\n");
		testText.setText("success");
		
		}
		 
		//Parse Json
		JSONTokener tokener = new JSONTokener(jsonBuilder.toString());
		JSONArray jsonArray = new JSONArray(tokener);
		
		//ArrayList<String> fields = new ArrayList<String>();
		
		
		for (int index = 0; index < jsonArray.length(); index++) {
			//Set both values into the listview
			JSONObject jsonObject = jsonArray.getJSONObject(index);
			
			String psAge = jsonObject.getString("age");
			String psReason = jsonObject.getString("reason");
			String psPoints = jsonObject.getString("points");

			//fields.add(jsonObject.getString("reason") + " - " + jsonObject.getString("points"));
		}
		 
		//setListAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, fields));
		
		} catch (FileNotFoundException e) {
		Log.e("jsonFile", "file not found");
		
		} catch (IOException e) {
		Log.e("jsonFile", "ioerror");
		
		} catch (JSONException e) {
		e.printStackTrace();
		}

		}


}