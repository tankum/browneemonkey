package com.tp.brwnee;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class childHistory {

	public static final String KEY_ROWID = "_id";
	public static final String KEY_CHILD = "_identity";
	public static final String KEY_CHILDNAME = "_name";
	public static final String KEY_DATE = "_date";
	public static final String KEY_ACTIVITY = "_activity";
	public static final String KEY_TYPE = "_type";
	public static final String KEY_POINTS = "_points";

	private static final String DATABASE_NAME = "historyDb";
	private static final String DATABASE_TABLE = "historyTable";
	private static final int DATABASE_VERSION = 1;

	private DbHelper histHelper;
	private Context histContext;
	private SQLiteDatabase histDatabase;

	private class DbHelper extends SQLiteOpenHelper{

		public DbHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL("CREATE TABLE " + DATABASE_TABLE + " ("+
					KEY_ROWID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
					KEY_CHILD + " TEXT NOT NULL, " +
					KEY_CHILDNAME + " TEXT NOT NULL, " +
					KEY_DATE + " TEXT NOT NULL, " +
					KEY_ACTIVITY + " TEXT NOT NULL, " +
					KEY_TYPE + " TEXT NOT NULL, " +
					KEY_POINTS + " TEXT NOT NULL);"
					);
			}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
		}
	}

	public childHistory(Context cH){
		histContext = cH;
	}
	
	public childHistory open() throws SQLException{
		histHelper = new DbHelper(histContext);
		histDatabase = histHelper.getWritableDatabase();
		return this;
	}
	
	public void close(){
		histHelper.close();
	}

	public long createHistEntry(String histChild, String histChildname, String histDate, String histActivity, String histType, String histPoints) {
		
		// TODO Auto-generated method stub
		ContentValues cv = new ContentValues();
		cv.put(KEY_CHILD, histChild);
		cv.put(KEY_CHILDNAME, histChildname);
		cv.put(KEY_DATE, histDate);
		cv.put(KEY_ACTIVITY, histActivity);
		cv.put(KEY_TYPE, histType);
		cv.put(KEY_POINTS, histPoints);
		
		return histDatabase.insert(DATABASE_TABLE, null, cv);
		
	}

	public Cursor readHistEntry() {
		// TODO Auto-generated method stub
		
		String[] columns = new String[]{KEY_ROWID, KEY_CHILDNAME, KEY_CHILD, KEY_DATE, KEY_ACTIVITY, KEY_TYPE, KEY_POINTS};
		Cursor k = histDatabase.query(DATABASE_TABLE, columns, null, null, null, null, null);
		if(k!=null){
			k.moveToFirst();
		}
		return k;
	}

	

	public void delete(String childUnId) {
		// TODO Auto-generated method stub
		try
	    {
	        histDatabase.delete(DATABASE_TABLE, KEY_CHILD + "=" + childUnId, null);
	    }
	    catch(Exception e)
	    {
	        e.printStackTrace();
	    }
	    finally
	    {
	        histDatabase.close();
	    }

	}
}
