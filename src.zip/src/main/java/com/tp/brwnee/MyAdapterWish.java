package com.tp.brwnee;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import android.widget.ImageButton;

public class MyAdapterWish extends ArrayAdapter<ItemWish>{

    private final Context context;
    private final ArrayList<ItemWish> itemsArrayList;

    public MyAdapterWish(Context context, ArrayList<ItemWish> itemsArrayList) {

        super(context, R.layout.reason_wish, itemsArrayList);

        this.context = context;
        this.itemsArrayList = itemsArrayList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        // 1. Create inflater
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        // 2. Get rowView from inflater
        final View rowView = inflater.inflate(R.layout.reason_wish, parent, false);

        // 3. Get the two text view from the rowView
        TextView reason = (TextView) rowView.findViewById(R.id.tvdbReason);
        TextView points = (TextView) rowView.findViewById(R.id.tvdbPoints);
        TextView reasonId = (TextView) rowView.findViewById(R.id.tvdbReasonRow);
        ImageButton brand = (ImageButton) rowView.findViewById(R.id.ibBrand);
        TextView price = (TextView) rowView.findViewById(R.id.tvdbPrice);
        TextView url = (TextView) rowView.findViewById(R.id.tvdbUrl);
        String brandName = (String) itemsArrayList.get(position).getWBrand();

          if(brandName=="flipkart"){
              brand.setImageResource(R.drawable.br_flipkart);
          }else if(brandName=="amazon"){
              brand.setImageResource(R.drawable.br_amazon);
          }else if(brandName=="jabong"){
              brand.setImageResource(R.drawable.br_jabong);
          }else if(brandName=="self"){
              brand.setImageResource(R.drawable.br_self);
          }

        // 4. Set the text for textView
        reason.setText(itemsArrayList.get(position).getReason());
        points.setText(itemsArrayList.get(position).getPoints());
        reasonId.setText(itemsArrayList.get(position).getRowId());
        price.setText(itemsArrayList.get(position).getWPrice());
        url.setText(itemsArrayList.get(position).getWUrl());

        return rowView;
    }

}


