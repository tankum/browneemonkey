package com.tp.brwnee;

import java.util.ArrayList;
import java.util.Collections;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;


public class MainActivity extends Activity implements OnClickListener{
	
	TextView title, chName, pageTitle, pageSub;
	ImageButton addChild;
	Bitmap cPht;
	RelativeLayout pageBody;
	Button firstChild;
	ImageView brwneeMan;
	@SuppressLint("NewApi")
	@Override
	
	protected void onCreate(Bundle savedInstanceState) {
		
		//recreate();
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		title = (TextView) findViewById(R.id.tvTitle);
		firstChild = (Button) findViewById(R.id.bAddFirstChild);
		brwneeMan = (ImageView) findViewById(R.id.imageView1);
		pageTitle = (TextView) findViewById(R.id.tvPage);
		pageSub =(TextView) findViewById(R.id.tvSubPage);
		pageBody = (RelativeLayout) findViewById(R.id.rlBody);
		addChild = (ImageButton) findViewById(R.id.bAddChild);


		Animation slideUpPage = AnimationUtils.loadAnimation(this, R.anim.slideup_bottom);
		pageBody.startAnimation(slideUpPage);
		pageBody.setVisibility(View.VISIBLE);

		Animation slideIn = AnimationUtils.loadAnimation(this, R.anim.slidedown_in_slow);
		brwneeMan.startAnimation(slideIn);
		brwneeMan.setVisibility(View.VISIBLE);

		Animation zoomIn = AnimationUtils.loadAnimation(this, R.anim.zoom_in);
		addChild.startAnimation(zoomIn);

		Typeface custom_font01 = Typeface.createFromAsset(getAssets(), "fonts/Anton.ttf");
		pageTitle.setTypeface(custom_font01);
		firstChild.setTypeface(custom_font01);

		Typeface custom_font02 = Typeface.createFromAsset(getAssets(), "fonts/Copperplate.ttc");
		pageSub.setTypeface(custom_font02);

		Typeface custom_font03 = Typeface.createFromAsset(getAssets(), "fonts/IndieFlower.ttf");
		title.setTypeface(custom_font03);
		
		Brwnee ft = new Brwnee(this);
		ft.open();
		Cursor k = ft.readEntry();
		int cRows = k.getCount();
		ft.close();
		
		if(cRows != 0){
			final MyAdapter adapter = new MyAdapter(this, generateData());
			ListView myChildren = (ListView) findViewById(R.id.lvChildren);
			myChildren.setAdapter(adapter);	
			
			myChildren.setOnItemClickListener(new AdapterView.OnItemClickListener() {
	            @Override
	            public void onItemClick (AdapterView<?> parent, View view,int position, long id) {
	                
	            	Context context = view.getContext();
	            	TextView textViewItem = ((TextView) view.findViewById(R.id.label));
	            	TextView textViewId = ((TextView) view.findViewById(R.id.rowId));
					TextView textViewAge = ((TextView) view.findViewById(R.id.tvAge));
	            	
	            	// get the clicked item name
	            	String listItemText = textViewItem.getText().toString();
	            	
	            	// get the clicked item ID
	            	String listItemId = textViewId.getText().toString();

					String listItemAge = textViewAge.getText().toString();
	            	
	          
	    			Bundle basket = new Bundle();
	    			basket.putString("key", listItemId);
	    			basket.putString("name", listItemText);
					basket.putString("age", listItemAge);
	    			
	    			Intent i = new Intent("com.tp.brwnee.CHILDDETAILS");
	    			i.putExtras(basket);
	            	startActivity(i);

			      }
			});
		}
		
		else{
			title.setVisibility(View.VISIBLE);
			firstChild.setVisibility(View.VISIBLE);
		}
		

		
		addChild.setOnClickListener(this);
		firstChild.setOnClickListener(this);
		
		
	}

	private ArrayList<Item> generateData() {
		// TODO Auto-generated method stub
		ArrayList<Item> items = new ArrayList<Item>();

		Brwnee getChild = new Brwnee(this);		
		getChild.open();
		
		Cursor c = getChild.readEntry();
		int rows = c.getCount();
		//int cols = c.getColumnCount();
		getChild.close();

		c.moveToFirst();
		
		if(rows != 0){
			//title.setText("");
			title.setVisibility(View.GONE);
			firstChild.setVisibility(View.GONE);
			
			for(int i = 0; i<rows; i++){
				
				//String desc = "Age:" + c.getString(3) + ", Points:" + c.getString(2) + ", Gender:" + c.getString(4);
				String desc = c.getString(2);
				
				byte[] imgChild = c.getBlob(8);
				cPht =  BitmapFactory.decodeByteArray(imgChild, 0, imgChild.length);
				
				String age = c.getString(3) + "yrs" + " " + c.getString(4);
				items.add(new Item(c.getString(1), desc, c.getString(0), cPht, age));
				
				c.moveToNext();
				
			}	
			
			Collections.reverse(items);
			return items;
			
		}else{
			title.setVisibility(View.VISIBLE);
			firstChild.setVisibility(View.VISIBLE);
			return null;
		}
	}



	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
		case R.id.bAddChild:
			Intent i = new Intent("com.tp.brwnee.ADDCHILD");
			startActivity(i);
			finish();
			break;
			
		case R.id.bAddFirstChild:
			Intent k = new Intent("com.tp.brwnee.ADDCHILD");
			startActivity(k);
			finish();
			break;
		}
	}
	
	@Override
	protected void onResume() {

	   super.onResume();
	   this.onCreate(null);
	}
	
	

}
