package com.tp.brwnee;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class SubtractReasonList extends Activity implements OnClickListener{
	ImageButton addReasonS, clearReasonS, noBrowneeS;
	TextView actionS, actionSubS, pageTitle, pageSub, addReasonTitle, modifyReasonTitle;
	LinearLayout newReasonS, modifyReasonS;
	RelativeLayout pageBody;
	
	EditText pointsS, reasonS, modPointsS, modReasonS, rowUnIdS;
	Button addS, cancelS, presetsBtnS, modButS, canButS;
	String childUnId, childAge, childName, rowReason, rowPoints, rowId, fDate, fTime, fWeekDay;
	FrameLayout overlayS;
	ListView myReasons, listvS;
	ImageView brwneeMan;
	Integer childAgeNum, currentposition;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.subtract_reason_list);

		Bundle gotBasket = getIntent().getExtras();
		childUnId = gotBasket.getString("chUnId");
		childAge= gotBasket.getString("chAge");
		childName= gotBasket.getString("chName");
		
		addReasonS = (ImageButton) findViewById(R.id.bAddReasonS);
		clearReasonS = (ImageButton) findViewById(R.id.bClearReasonS);
		actionS = (TextView) findViewById(R.id.tvActionS);
		actionSubS = (TextView) findViewById(R.id.tvActionS01);
		addReasonTitle = (TextView) findViewById(R.id.tvAddReasonTitle);
		modifyReasonTitle = (TextView) findViewById(R.id.tvModifyReasonTitle);
		noBrowneeS = (ImageButton) findViewById(R.id.bNobrowneeS);
		presetsBtnS = (Button) findViewById(R.id.btnPresetsS);
		brwneeMan = (ImageView) findViewById(R.id.imageView1);

		pageTitle = (TextView) findViewById(R.id.tvPage);
		pageSub =(TextView) findViewById(R.id.tvSubPage);
		pageBody = (RelativeLayout) findViewById(R.id.rlListContainer);

		newReasonS = (LinearLayout) findViewById(R.id.llNewReasonS);
		pointsS = (EditText) findViewById(R.id.etPointsS);
		reasonS = (EditText) findViewById(R.id.etReasonS);

		listvS= (ListView) findViewById(R.id.lvReasonsS);

		modifyReasonS = (LinearLayout) findViewById(R.id.llModReasonS);
		modPointsS = (EditText) findViewById(R.id.etModPointsS);
		modReasonS = (EditText) findViewById(R.id.etModReasonS);
		rowUnIdS = (EditText) findViewById(R.id.etRowS);

		overlayS = (FrameLayout) findViewById(R.id.flOverlayS);
		
		addS = (Button) findViewById(R.id.bSubmitS);		
		cancelS= (Button) findViewById(R.id.bCancelS);

		modButS = (Button) findViewById(R.id.bModSubmitS);
		canButS= (Button) findViewById(R.id.bModCancelS);

		Animation slideIn = AnimationUtils.loadAnimation(this, R.anim.slidedown_in_slow);
		brwneeMan.startAnimation(slideIn);
		brwneeMan.setVisibility(View.VISIBLE);

		Animation slideUpPage = AnimationUtils.loadAnimation(this, R.anim.slideup_bottom);
		pageBody.startAnimation(slideUpPage);

		Animation zoomOut = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		clearReasonS.startAnimation(zoomOut);
		addReasonS.startAnimation(zoomOut);

		Typeface custom_font01 = Typeface.createFromAsset(getAssets(), "fonts/Anton.ttf");
		pageTitle.setTypeface(custom_font01);
		presetsBtnS.setTypeface(custom_font01);
		addReasonTitle.setTypeface(custom_font01);
		modifyReasonTitle.setTypeface(custom_font01);

		Typeface custom_font02 = Typeface.createFromAsset(getAssets(), "fonts/Copperplate.ttc");
		pageSub.setTypeface(custom_font02);

		Typeface custom_font03 = Typeface.createFromAsset(getAssets(), "fonts/IndieFlower.ttf");
		actionS.setTypeface(custom_font03);

		addReasonS.setOnClickListener(this);
		clearReasonS.setOnClickListener(this);
		addS.setOnClickListener(this);
		cancelS.setOnClickListener(this);
		noBrowneeS.setOnClickListener(this);
		modButS.setOnClickListener(this);
		canButS.setOnClickListener(this);
		presetsBtnS.setOnClickListener(this);

		makeList();
		updateTime();

		final Handler h = new Handler();
		h.post(new Runnable() {
			@Override
			public void run() {
				updateTime();
				h.postDelayed(this, 1000);
			}
		});
	}

	public void updateTime(){
		Calendar c = Calendar.getInstance();


		SimpleDateFormat df = new SimpleDateFormat("hh:mm aa");
		SimpleDateFormat ds = new SimpleDateFormat("dd-MM-yyyy");
		SimpleDateFormat sdf = new SimpleDateFormat("EEEE");

		String formattedTime = df.format(c.getTime());
		String formattedDate = ds.format(c.getTime());
		String formattedDay = sdf.format(c.getTime());

		fDate = formattedDate;
		fTime = formattedTime;
		fWeekDay = formattedDay;
	}

	private void makeList(){
		// Setting up the list of reasons
		PointReasons cRsns = new PointReasons(this);

		cRsns.open();
		Cursor r = cRsns.readReasonEntry();
		int n = r.getCount();
		cRsns.close();

		if(n!=0){
			final MyAdapterReason rAdapter = new MyAdapterReason(this, generateReasonData());
			myReasons = (ListView) findViewById(R.id.lvReasonsS);
			myReasons.setAdapter(rAdapter);
			registerForContextMenu(myReasons);

			myReasons.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick (AdapterView<?> parent, View view,int position, long id) {

					Context context = view.getContext();
					TextView reasonItem = ((TextView) view.findViewById(R.id.tvdbReason));
					TextView reasonId = ((TextView) view.findViewById(R.id.tvdbReasonRow));
					TextView pointItem = ((TextView) view.findViewById(R.id.tvdbPoints));

					// get the clicked item details
					String clReason = reasonItem.getText().toString();
					String clReasonId = reasonId.getText().toString();
					String clPoints = pointItem.getText().toString();

					String rType = "Sub";
					String histDate = fDate + " | " + fTime + " | " + fWeekDay;

					childHistory hist = new childHistory(SubtractReasonList.this);
					hist.open();
					hist.createHistEntry(childUnId, childName, histDate, clReason, rType, clPoints);
					hist.close();


					Intent addThis = new Intent();
					Bundle good = new Bundle();
					good.putString("spnt", clPoints);
					good.putString("srsn", clReason);

					addThis.putExtras(good);
					setResult(RESULT_OK, addThis);
					finish();

				}
			});

		}
	}


	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
		if (v.getId()==R.id.lvReasonsS) {
			AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)menuInfo;

			//menu.setHeaderTitle("Options");
			rowReason = ((TextView)info.targetView.findViewById(R.id.tvdbReason)).getText().toString();
			rowPoints = ((TextView)info.targetView.findViewById(R.id.tvdbPoints)).getText().toString();
			rowId = ((TextView)info.targetView.findViewById(R.id.tvdbReasonRow)).getText().toString();

			String[] menuItems = new String[] {"Edit","Delete"};
			for (int i = 0; i<menuItems.length; i++) {
				menu.add(Menu.NONE, i, i, menuItems[i]);
			}
		}
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
		int menuItemIndex = item.getItemId();
		String[] menuItems = new String[] {"Edit","Delete"};
		String menuItemName = menuItems[menuItemIndex];

		if (menuItemName == "Edit") {
			if(modifyReasonS.getVisibility() == View.VISIBLE){
				overlayS.setVisibility(View.GONE);
				Animation slideOut = AnimationUtils.loadAnimation(this, R.anim.slidedown_out);
				modifyReasonS.startAnimation(slideOut);
				modifyReasonS.setVisibility(View.GONE);

				modPointsS.setText("");
				modReasonS.setText("");
				rowUnIdS.setText("");

			}else{
				overlayS.setVisibility(View.VISIBLE);
				Animation slideIn = AnimationUtils.loadAnimation(this, R.anim.slidedown_in);
				modifyReasonS.startAnimation(slideIn);
				modifyReasonS.setVisibility(View.VISIBLE);

				modPointsS.setText(rowPoints);
				modReasonS.setText(rowReason);
				rowUnIdS.setText(rowId);
			}
		}
		if (menuItemName == "Delete") {
			long lR = Long.parseLong(rowId);
			PointReasons delReason = new PointReasons(this);

			delReason.open();
			delReason.deleteEntry(lR);
			delReason.close();

			makeList();
		}

		return true;
	}


	private ArrayList<ItemReason> generateReasonData() {
		// TODO Auto-generated method stub
		ArrayList<ItemReason> reasonItems = new ArrayList<ItemReason>();
		
		PointReasons pRsns = new PointReasons(this);
		pRsns.open();
		Cursor k = pRsns.readReasonEntry();
		int p = k.getCount();
		pRsns.close();
		
		k.moveToFirst();
		
		if(p!=0){
			for (int i=0; i<p;i++){
				if(k.getString(3).equals("Sub") && k.getString(4).equals(childUnId)){
					listvS.setVisibility(View.VISIBLE);
					actionS.setVisibility(View.GONE);
					actionSubS.setVisibility(View.GONE);
					presetsBtnS.setVisibility(View.GONE);

					reasonItems.add(new ItemReason(k.getString(1), k.getString(2), k.getString(0)));						
				}
				k.moveToNext();	
			}				
			Collections.reverse(reasonItems);
			return reasonItems;			
		}else{
			listvS.setVisibility(View.GONE);
			//actionS.setText("You do not have any reasons added");
			return null;
		}
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){


			case R.id.btnPresetsS:

				listvS.setVisibility(View.VISIBLE);

				try
				{
					//Load File
					childAgeNum = Integer.parseInt(childAge);

					if(childAgeNum>0 && childAgeNum <=5){
						BufferedReader jsonReader = new BufferedReader(new InputStreamReader(this.getResources().openRawResource(R.raw.reasonsearlysub)));
						StringBuilder jsonBuilder = new StringBuilder();
						for (String line = null; (line = jsonReader.readLine()) != null;) {
							jsonBuilder.append(line).append("\n");

						}
						//Parse Json
						JSONTokener tokener = new JSONTokener(jsonBuilder.toString());
						JSONArray jsonArray = new JSONArray(tokener);

						for (int index = 0; index < jsonArray.length(); index++) {
							//Set both values into the listview
							JSONObject jsonObject = jsonArray.getJSONObject(index);

							String psReason = jsonObject.getString("reason");
							String psPoints = jsonObject.getString("points");
							String psType = jsonObject.getString("type");

							PointReasons preR = new PointReasons(SubtractReasonList.this);
							preR.open();
							preR.createReasonEntry(psReason, psPoints, psType, childUnId);
							preR.close();
						}

					}else if(childAgeNum>5 && childAgeNum <=9){
						BufferedReader jsonReader = new BufferedReader(new InputStreamReader(this.getResources().openRawResource(R.raw.reasonsmidsub)));
						StringBuilder jsonBuilder = new StringBuilder();
						for (String line = null; (line = jsonReader.readLine()) != null;) {
							jsonBuilder.append(line).append("\n");

						}
						//Parse Json
						JSONTokener tokener = new JSONTokener(jsonBuilder.toString());
						JSONArray jsonArray = new JSONArray(tokener);

						for (int index = 0; index < jsonArray.length(); index++) {
							//Set both values into the listview
							JSONObject jsonObject = jsonArray.getJSONObject(index);

							String psReason = jsonObject.getString("reason");
							String psPoints = jsonObject.getString("points");
							String psType = jsonObject.getString("type");

							PointReasons preR = new PointReasons(SubtractReasonList.this);
							preR.open();
							preR.createReasonEntry(psReason, psPoints, psType, childUnId);
							preR.close();
						}

					}else if(childAgeNum>9 && childAgeNum <=14){
						BufferedReader jsonReader = new BufferedReader(new InputStreamReader(this.getResources().openRawResource(R.raw.reasonsteensub)));
						StringBuilder jsonBuilder = new StringBuilder();
						for (String line = null; (line = jsonReader.readLine()) != null;) {
							jsonBuilder.append(line).append("\n");

						}
						//Parse Json
						JSONTokener tokener = new JSONTokener(jsonBuilder.toString());
						JSONArray jsonArray = new JSONArray(tokener);

						for (int index = 0; index < jsonArray.length(); index++) {
							//Set both values into the listview
							JSONObject jsonObject = jsonArray.getJSONObject(index);

							String psReason = jsonObject.getString("reason");
							String psPoints = jsonObject.getString("points");
							String psType = jsonObject.getString("type");

							PointReasons preR = new PointReasons(SubtractReasonList.this);
							preR.open();
							preR.createReasonEntry(psReason, psPoints, psType, childUnId);
							preR.close();
						}

					}else if(childAgeNum>14){
						BufferedReader jsonReader = new BufferedReader(new InputStreamReader(this.getResources().openRawResource(R.raw.reasonshighsub)));
						StringBuilder jsonBuilder = new StringBuilder();
						for (String line = null; (line = jsonReader.readLine()) != null;) {
							jsonBuilder.append(line).append("\n");

						}
						//Parse Json
						JSONTokener tokener = new JSONTokener(jsonBuilder.toString());
						JSONArray jsonArray = new JSONArray(tokener);

						for (int index = 0; index < jsonArray.length(); index++) {
							//Set both values into the listview
							JSONObject jsonObject = jsonArray.getJSONObject(index);

							String psReason = jsonObject.getString("reason");
							String psPoints = jsonObject.getString("points");
							String psType = jsonObject.getString("type");

							PointReasons preR = new PointReasons(SubtractReasonList.this);
							preR.open();
							preR.createReasonEntry(psReason, psPoints, psType, childUnId);
							preR.close();
						}

					}


				} catch (FileNotFoundException e) {
					Log.e("jsonFile", "file not found");

				} catch (IOException e) {
					Log.e("jsonFile", "ioerror");

				} catch (JSONException e) {
					e.printStackTrace();
				}

				makeList();

				break;
		case R.id.bAddReasonS:

			if(newReasonS.getVisibility() == View.VISIBLE){
				overlayS.setVisibility(View.GONE);
				Animation slideOut = AnimationUtils.loadAnimation(this, R.anim.slidedown_out);
				newReasonS.startAnimation(slideOut);
				newReasonS.setVisibility(View.GONE);
				
			}else{
				overlayS.setVisibility(View.VISIBLE);
				Animation slideIn = AnimationUtils.loadAnimation(this, R.anim.slidedown_in);
				newReasonS.startAnimation(slideIn);
				newReasonS.setVisibility(View.VISIBLE);
				
			}
			
			/*Intent aR = new Intent(AddReasonList.this, AddPoints.class);
			startActivityForResult(aR,0);*/		
			break;
		
		case R.id.bClearReasonS:
			String reasonType = "Sub";
			
			PointReasons clearAll = new PointReasons(SubtractReasonList.this);
			clearAll.open();
			clearAll.deleteReason(reasonType, childUnId);
			clearAll.close();
			
			ListView list = (ListView) findViewById(R.id.lvReasonsS);
			list.setVisibility(View.GONE);
			actionS.setVisibility(View.VISIBLE);
			actionSubS.setVisibility(View.VISIBLE);
			presetsBtnS.setVisibility(View.VISIBLE);

			break;
			
		case R.id.bNobrowneeS:
			Intent noBrwn = new Intent();
			setResult(RESULT_CANCELED, noBrwn);
			finish();
			break;
		
		case R.id.bSubmitS:
			
			boolean reasonAdded = true;

			if (isEmpty(pointsS) || isEmpty(reasonS)) {
				reasonAdded = false;
				openAlert(v);
			}else {
				try{
					String toAdd = pointsS.getText().toString();
					String pReason = reasonS.getText().toString();
					String rType = "Sub";
					String histDate = fDate + " | " + fTime + " | " + fWeekDay;

					PointReasons newR = new PointReasons(SubtractReasonList.this);
					newR.open();
					newR.createReasonEntry(pReason, toAdd, rType, childUnId);
					newR.close();

					childHistory hist = new childHistory(SubtractReasonList.this);
					hist.open();
					hist.createHistEntry(childUnId, childName, histDate, pReason, rType, toAdd);
					hist.close();

				}catch(Exception e){
					reasonAdded = false;
					String error=e.toString();
					Dialog d = new Dialog(this);
					d.setTitle("Sorry");
					TextView tv = new TextView(this);
					tv.setText(error);
					d.setContentView(tv);
					d.show();
				}finally{

					String toAdd = pointsS.getText().toString();
					String pReason = reasonS.getText().toString();

					Intent addThis = new Intent();
					Bundle good = new Bundle();

					if(pReason != null){
						good.putString("srsn", pReason);
					}
					else{
						good.putString("srsn", "no reason mentioned");
					}

					if(toAdd != null){
						good.putString("spnt", toAdd);
					}
					else{
						good.putString("spnt", "0");
					}

					addThis.putExtras(good);
					setResult(RESULT_OK, addThis);
					finish();
				}
			}
			


			break;
			
		case R.id.bCancelS:						
			overlayS.setVisibility(View.GONE);
			Animation slideOut = AnimationUtils.loadAnimation(this, R.anim.slidedown_out);
			newReasonS.startAnimation(slideOut);
			newReasonS.setVisibility(View.GONE);
			break;

			case R.id.bModSubmitS:

				boolean modifyAdded = true;

				if (isEmpty(modPointsS) || isEmpty(modReasonS)) {
					modifyAdded = false;
					openAlert(v);
				}else {

					try {
						String toAdd = modPointsS.getText().toString();
						String pReason = modReasonS.getText().toString();
						String rType = "Sub";
						long rUD = Long.parseLong(rowUnIdS.getText().toString());

						PointReasons newR = new PointReasons(SubtractReasonList.this);
						newR.open();
						newR.modifyEntry(rUD, pReason, toAdd, rType, childUnId);
						newR.close();

					} catch (Exception e) {
						modifyAdded = false;
						String error = e.toString();
						Dialog d = new Dialog(this);
						d.setTitle("Sorry");
						TextView tv = new TextView(this);
						tv.setText(error);
						d.setContentView(tv);
						d.show();
					} finally {


						overlayS.setVisibility(View.GONE);
						Animation slideOutMod = AnimationUtils.loadAnimation(this, R.anim.slidedown_out);
						modifyReasonS.startAnimation(slideOutMod);
						modifyReasonS.setVisibility(View.GONE);

						View view = this.getCurrentFocus();
						if (view != null) {
							InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
							imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
						}

						makeList();
					}
				}

				break;

			case R.id.bModCancelS:
				overlayS.setVisibility(View.GONE);
				Animation slideOutMod = AnimationUtils.loadAnimation(this, R.anim.slidedown_out);
				modifyReasonS.startAnimation(slideOutMod);
				modifyReasonS.setVisibility(View.GONE);
				break;
		}
	}

	private void openAlert(View view) {
		// TODO Auto-generated method stub
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(SubtractReasonList.this);


		// Get the layout inflater
		LayoutInflater inflater = SubtractReasonList.this.getLayoutInflater();

		// Inflate and set the layout for the dialog
		// Pass null as the parent view because its going in the dialog layout
		alertDialogBuilder.setView(inflater.inflate(R.layout.alert_dialog, null));


		// set negative button: No message
		alertDialogBuilder.setNegativeButton("Oops!!!", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				// cancel the alert box and put a Toast to the user
				dialog.cancel();
				Toast.makeText(getApplicationContext(), "Thanks for your patience.",
						Toast.LENGTH_LONG).show();
			}
		});



		AlertDialog alertDialog = alertDialogBuilder.create();
		// show alert
		alertDialog.show();
	}

	//checking for empty field
	private boolean isEmpty(EditText myeditText) {
		return myeditText.getText().toString().trim().length() == 0;
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}
	
}
