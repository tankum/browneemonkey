package com.tp.brwnee;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.PorterDuff.Mode;

public class Item {
	 
    private String title;
    private String description;
    private String rowId;
    private String age;
    private Bitmap rePhoto;

 
    public Item(String title, String description, String rowId, Bitmap cPht, String age) {
        super();
        this.title = title;
        this.description = description;
        this.rowId = rowId;
        this.age = age;
        
        Bitmap resized = Bitmap.createScaledBitmap(cPht, 300, 300, true);
        Bitmap conv_ch = getRoundedRectBitmap(resized, 300);
        //childPhoto.setImageBitmap(conv_ch);
        
        this.rePhoto = conv_ch;
    }
 

    @SuppressWarnings("deprecation")
	public static Bitmap getRoundedRectBitmap(Bitmap bitmap, int pixels) {
	    Bitmap result = null;
	    try {
	        result = Bitmap.createBitmap(300, 300, Bitmap.Config.ARGB_8888);
	        Canvas canvas = new Canvas(result);

	        int color = 0xff424242;
	        Paint paint = new Paint();
	        Rect rect = new Rect(0, 0, 300, 300);

	        paint.setAntiAlias(true);
	        canvas.drawARGB(0, 0, 0, 0);
	        paint.setColor(color); 
	        canvas.drawCircle(150, 150, 150, paint);
	        paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
	        canvas.drawBitmap(bitmap, rect, rect, paint);

	    } catch (NullPointerException e) {
	    } catch (OutOfMemoryError o) {
	    }
	    return result;
	}


	public CharSequence getTitle() {
		// TODO Auto-generated method stub
		return title;
	}

	public CharSequence getDescription() {
		// TODO Auto-generated method stub
		return description;
	}
	
	public CharSequence getrowId() {
		// TODO Auto-generated method stub
		return rowId;
	}
	
	public Bitmap getrePhoto() {
		// TODO Auto-generated method stub
		return rePhoto;
	}


	public CharSequence getAge() {
		// TODO Auto-generated method stub
		return age;
	}
}
