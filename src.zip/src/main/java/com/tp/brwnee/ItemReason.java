package com.tp.brwnee;

public class ItemReason {
	 
    private String reason;
    private String points;
    private String rowId;
 
    public ItemReason(String reason, String points, String rowId) {
        super();
        this.reason = reason;
        this.points = points;
        this.rowId = rowId;
    }
 


	public CharSequence getReason() {
		// TODO Auto-generated method stub
		return reason;
	}

	public CharSequence getPoints() {
		// TODO Auto-generated method stub
		return points;
	}
	
	public CharSequence getRowId() {
		// TODO Auto-generated method stub
		return rowId;
	}
}
