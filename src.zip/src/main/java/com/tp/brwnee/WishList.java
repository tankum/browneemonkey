package com.tp.brwnee;

import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class WishList {
	
	public static final String KEY_ROWID = "_id";
	public static final String KEY_WISH = "_wish";
	public static final String KEY_REQPOINTS = "_reqpoints";
	public static final String KEY_CHILD = "_child";
	public static final String KEY_BRAND="_brand";
	public static final String KEY_PRICE="_price";
	public static final String KEY_URL="_url";
	
	private static final String DATABASE_NAME = "wishDb";
	private static final String DATABASE_TABLE = "wishTable";
	private static final int DATABASE_VERSION = 1;
	
	private DbHelper wishHelper;
	private Context wishContext;
	private SQLiteDatabase wishDatabase;
	
	private class DbHelper extends SQLiteOpenHelper{

		public DbHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL("CREATE TABLE " + DATABASE_TABLE + " ("+
					KEY_ROWID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
					KEY_WISH + " TEXT NOT NULL, " +
					KEY_REQPOINTS + " TEXT NOT NULL, " +
					KEY_CHILD + " TEXT NOT NULL, " +
					KEY_BRAND + " TEXT NOT NULL, " +
					KEY_PRICE + " TEXT NOT NULL, " +
					KEY_URL + " TEXT NOT NULL);"
					);
			}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);			
		}		
	}
	
	public WishList(Context cW){
		wishContext = cW;
	}
	
	public WishList open() throws SQLException{
		wishHelper = new DbHelper(wishContext);
		wishDatabase = wishHelper.getWritableDatabase();	
		return this;
	}
	
	public void close(){
		wishHelper.close();
	}

	public long createWishEntry(String wish, String reqPoints, String childUnId, String wBrand, String wPrice, String wUrl) {
		
		// TODO Auto-generated method stub
		ContentValues cv = new ContentValues();
		cv.put(KEY_WISH, wish);
		cv.put(KEY_REQPOINTS, reqPoints);
		cv.put(KEY_CHILD, childUnId);
		cv.put(KEY_BRAND, wBrand);
		cv.put(KEY_PRICE, wPrice);
		cv.put(KEY_URL, wUrl);
		
		return wishDatabase.insert(DATABASE_TABLE, null, cv);
		
	}

	public Cursor readReasonEntry() {
		// TODO Auto-generated method stub
		
		String[] columns = new String[]{KEY_ROWID, KEY_WISH, KEY_REQPOINTS, KEY_CHILD, KEY_BRAND, KEY_PRICE, KEY_URL};
		Cursor k = wishDatabase.query(DATABASE_TABLE, columns, null, null, null, null, null);
		if(k!=null){
			k.moveToFirst();
		}
		return k;
	}

	public void modifyEntry(long rUD, String wWish, String wPnts, String wChild, String wBrand, String wPrice, String wUrl) {
		// TODO Auto-generated method stub

		ContentValues cvUpdate = new ContentValues();
		cvUpdate.put(KEY_WISH, wWish);
		cvUpdate.put(KEY_REQPOINTS, wPnts);
		cvUpdate.put(KEY_CHILD, wChild);
		cvUpdate.put(KEY_BRAND, wBrand);
		cvUpdate.put(KEY_PRICE, wPrice);
		cvUpdate.put(KEY_URL, wUrl);

		wishDatabase.update(DATABASE_TABLE, cvUpdate, KEY_ROWID + "=" + rUD, null);

	}

	public void deleteEntry(long lR) {
		// TODO Auto-generated method stub
		wishDatabase.delete(DATABASE_TABLE, KEY_ROWID + "=" + lR, null);
	}

	public void deleteWish(String childUnId) {
		// TODO Auto-generated method stub
		try
		{
			wishDatabase.delete(DATABASE_TABLE, KEY_CHILD + "=" + childUnId, null);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally {
			wishDatabase.close();
		}
		
	}
}
